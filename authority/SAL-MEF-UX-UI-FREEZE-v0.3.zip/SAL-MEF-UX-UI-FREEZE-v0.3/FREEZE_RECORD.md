# SAL-MEF UX/UI Design Freeze Record

**Document ID:** SAL-MEF-UX-UI-FREEZE  
**Version:** 0.3.0  
**Freeze date:** 2026-08-04  
**Status:** FROZEN_FOR_IMPLEMENTATION_PLANNING  
**Product:** Measurement Evidence Factory Agent  
**Future umbrella system:** AgentSportsLab

## Decision

The practitioner-facing experience architecture for the first Measurement Evidence Factory Agent product is frozen at the level required to begin implementation planning.

The product is a desktop-first, longitudinal measurement and evidence workspace for repeated force-plate countermovement-jump assessments. It is not a generic sports dashboard, a medical application, a chatbot-first product, or the completed AgentSportsLab multi-agent system.

## Frozen product boundary

- Active device family: force plates only.
- Active assessment family: countermovement jump only.
- Initial protocol: bilateral, unloaded, hands-on-hips CMJ.
- Active data source: supported native force-plate vendor exports.
- Primary signal scope: qualified vertical ground-reaction-force channels.
- Primary user: strength and conditioning coach, applied sport scientist, or qualified performance practitioner.
- Human practitioner retains final interpretation and downstream authority.
- The persistent assistant is the Measurement Evidence Factory Agent, visible throughout the core product and backed by bounded durable memory.

## Frozen experience architecture

- Overview is the longitudinal operational dashboard.
- Tests contains the session registry, Metric Explorer, and entry into a test-detail evidence workspace.
- Force Plates & Imports owns upload, adapter resolution, acquisition configuration, and qualification status.
- Evidence owns traceability, replay, provenance, and audit history.
- Reports are generated only from accepted evidence records.
- Protocols & References owns approved test protocols, reference models, baseline epochs, and registered practical thresholds.
- Settings owns dashboard profiles, display preferences, permitted memory scopes, and authorized scientific policy configuration.

## Freeze level

The following are frozen:

- Product identity and scope.
- Global navigation.
- Core routes and screen families.
- Overview dashboard information hierarchy.
- Baseline/reference model controls.
- Rolling 7, 14, 28, and 30-day default comparisons.
- Rolling 3, 5, and 10-session reference options.
- Configurable qualified metric cards.
- Tests registry and Metric Explorer.
- Test-detail evidence workflow.
- Persistent assistant presence, context visibility, and memory boundaries.
- Human authority and prohibited output rules.
- Screen-level state semantics and critical acceptance invariants.

The following remain deliberately unfrozen:

- Exact pixel dimensions.
- Final typography family.
- Exact color values and iconography.
- Animation details.
- Final brand name for the assistant beyond the functional name "MEF Agent".
- Mobile-native experience.
- Future device and assessment families.
- Final high-fidelity visual polish.

## Superseded concepts

The following are rejected and must not reappear in the first product:

- AgentSportsLab as the current product name.
- Generic Devices screens containing unrelated sensors.
- ECG, EMG, EEG, PPG, respiratory, temperature, or clinical monitoring content.
- Patient terminology.
- Generic readiness, fatigue, injury-risk, diagnosis, or causal-training labels.
- A homepage dominated by upload shortcuts and generic SaaS metrics.
- An assistant that changes identity or loses context across screens.
- Arbitrary user-authored scientific formulas.

## Implementation authorization

This freeze authorizes implementation planning and technical decomposition. It does not by itself choose whether the first implementation work begins with the UI shell or the scientific software factory. That sequencing decision is intentionally separated into `IMPLEMENTATION_SEQUENCE_DECISION_BRIEF.md`.
