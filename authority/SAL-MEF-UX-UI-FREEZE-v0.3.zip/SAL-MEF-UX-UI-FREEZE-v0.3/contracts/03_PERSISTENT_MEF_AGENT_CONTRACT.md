# Persistent MEF Agent UX and Memory Contract

## Assistant identity

- Functional display name: MEF Agent.
- One identity across all core routes.
- Same thread continuity within a case.
- Same bounded workspace and athlete memory where authorized.

## Panel states

- Collapsed launcher.
- Docked compact summary.
- Expanded side panel.
- Focus mode for drafting or evidence walkthrough.

## Thread scopes

- Workspace thread.
- Athlete thread.
- Measurement-case thread.
- Temporary ad hoc thread.

Default in a test-detail workspace: measurement-case thread.

## Memory classes

1. UI memory: panel and draft state.
2. Active-session memory: current navigation and recent discussion.
3. Case memory: questions, explanations, drafts, unresolved issues.
4. Athlete memory: explicitly permitted historical context.
5. Workspace memory: terminology and practitioner preferences.
6. Explicit durable preferences: user-approved display and explanation preferences.

## Memory provenance

Every durable memory item records:

- Scope.
- Source.
- Author.
- Creation time.
- Verification state.
- Retention policy.
- Whether it is a fact, system state, assistant summary, practitioner note, or approved decision.

## Safety invariant

Unverified assistant summaries may never become scientific facts or practitioner decisions through memory persistence.

## Required response behavior

- Cite exact evidence objects.
- State the active reference model.
- Preserve uncertainty language.
- Identify missing information.
- Propose actions rather than execute authoritative actions.
- Make the user confirm any note, override, baseline, or threshold mutation.
