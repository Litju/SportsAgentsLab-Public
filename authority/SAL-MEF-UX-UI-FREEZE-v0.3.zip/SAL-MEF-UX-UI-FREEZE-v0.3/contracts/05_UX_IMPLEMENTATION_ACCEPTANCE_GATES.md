# UX Implementation Acceptance Gates

## Gate UX-0 - Contract conformance

- Product identity is correct.
- Navigation matches the frozen route model.
- No unrelated devices or medical content appears.
- Core states and domain terms match the contract.

## Gate UX-1 - Overview shell

- Fixed and rolling reference models work with mocked data.
- The actual count of comparable sessions is visible.
- Metric cards are configuration-driven.
- The primary plot shows reference and uncertainty.
- Review queue items open the relevant object.

## Gate UX-2 - Tests and Metric Explorer

- Metric selection is constrained to qualified definitions.
- Incompatible units are not overlaid without an explicit mode.
- Excluded and noncomparable sessions are visually distinct.
- A plotted point opens the test-detail workspace.

## Gate UX-3 - Test-detail workflow

- Every stage is reachable.
- Outstanding requirements remain visible.
- Trial signals, events, and metric observations are inspectable.
- Override preserves original evidence and requires a reason.

## Gate UX-4 - Persistent MEF Agent

- Same assistant identity on every screen.
- Thread survives navigation and reload.
- Active context is visible.
- Responses link to evidence.
- Agent cannot execute authoritative scientific or practitioner mutations.

## Gate UX-5 - Accessibility and safety

- Core workflows are keyboard operable.
- State is not encoded by color alone.
- No prohibited readiness, fatigue, injury, diagnosis, clearance, or causal label appears.
- Human and machine outputs are visually distinct.
