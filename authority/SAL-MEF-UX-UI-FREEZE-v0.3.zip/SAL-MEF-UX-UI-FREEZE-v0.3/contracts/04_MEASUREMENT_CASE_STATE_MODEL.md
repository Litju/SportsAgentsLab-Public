# Measurement Case UX State Model

## Canonical progression

`UPLOADED`
-> `IMPORTED`
-> `CONFIGURATION_UNRESOLVED`
-> `CONFIGURATION_RESOLVED`
-> `PROTOCOL_INCOMPLETE`
-> `PROCESSING_ELIGIBLE`
-> `TRIAL_REVIEW_REQUIRED`
-> `SESSION_ACCEPTED`
-> `INFERENCE_ELIGIBLE`
-> `PRACTITIONER_REVIEW_REQUIRED`
-> `PRACTITIONER_ACCEPTED`

## Branch and terminal states

- `UNSUPPORTED_EXPORT`
- `UNQUALIFIED_CONFIGURATION`
- `PROTOCOL_INVALID`
- `RETEST_REQUIRED`
- `INSUFFICIENT_VALID_TRIALS`
- `INSUFFICIENT_BASELINE`
- `NONCOMPARABLE_CONTEXT_ACCEPTED`
- `PRACTITIONER_OVERRIDDEN`
- `REJECTED`
- `INFERENCE_FAILED`

## UI rules

- Every state names the responsible actor.
- Every state exposes only permitted next actions.
- Review-required states use amber semantics.
- Invalid/unsupported terminal states use red semantics.
- Accepted states use green only for workflow confirmation, never athlete condition.
- Human override uses a distinct violet marker and preserves original system output.
