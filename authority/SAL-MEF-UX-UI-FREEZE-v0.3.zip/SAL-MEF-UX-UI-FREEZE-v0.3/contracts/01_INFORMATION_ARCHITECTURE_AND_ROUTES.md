# Information Architecture and Route Contract

## Global routes

| Route | Screen family | Primary object | MVP |
|---|---|---|---|
| `/overview` | Longitudinal overview | Athlete/cohort measurement state | Yes |
| `/tests` | Test registry and Metric Explorer | Test sessions | Yes |
| `/tests/:testId` | Test-detail workspace | Measurement case | Yes |
| `/athletes` | Athlete registry | Athletes | Yes |
| `/athletes/:athleteId` | Athlete CMJ history | Athlete | Yes |
| `/force-plates-imports` | Ingestion and acquisition | Source artifacts/configurations | Yes |
| `/evidence` | Evidence registry | Evidence manifests | Yes |
| `/evidence/:evidenceId` | Evidence lineage | One evidence record | Yes |
| `/reports` | Report registry | Accepted evidence reports | Yes |
| `/protocols-references` | Scientific policy registry | Protocols/reference policies | Yes, restricted |
| `/settings` | Workspace configuration | Preferences/roles/memory | Yes |

## Test-detail stage routes

The application may implement nested routes or a single route with stable stage state:

- `source`
- `configuration`
- `protocol`
- `trials`
- `session`
- `change`
- `decision`
- `evidence`

## Navigation rules

- Overview is the default authenticated landing route.
- Tests is the primary operational registry.
- No generic Analytics or Devices route is permitted.
- The assistant dock is mounted by the global authenticated shell, not per page.
- Current athlete, test, metric, and reference context must survive navigation where logically valid.
