# Screen Contract Registry

## Overview

Required modules:

- Context selectors.
- Baseline/reference selector.
- Qualified metric cards.
- Primary longitudinal plot.
- Rolling-window comparison.
- Review queue.
- Evidence/data-quality strip.
- MEF Agent dock.

Required states:

- No athlete/cohort selected.
- No accepted sessions.
- Insufficient baseline.
- Partial comparable data.
- Fully available.
- Reference model changed.
- Unsupported configuration present.
- Loading or inference pending.

## Tests

Required modules:

- Session registry.
- Filters.
- Metric Explorer.
- Saved views.
- MEF Agent dock.

Required states:

- Empty registry.
- Processing.
- Review required.
- Comparable accepted.
- Noncomparable accepted.
- Retest required.
- Rejected.

## Force Plates & Imports

Required modules:

- Upload dropzone.
- Supported adapter list.
- Recent imports.
- Schema mapping.
- Configuration resolver.
- Qualification verdict.
- MEF Agent dock.

## Athlete detail

Required modules:

- CMJ history.
- Approved references.
- Baseline maturity.
- Measurement cases.
- Evidence decisions.
- Practitioner annotations.
- MEF Agent dock.

## Evidence detail

Required modules:

- Lineage ladder.
- Integrity and version details.
- Calculation/inference records.
- Human decision chronology.
- Export/replay controls.
- MEF Agent dock.
