# Measurement Evidence Factory Agent - Frozen UX/UI Design Specification

**Specification ID:** SAL-MEF-UXD  
**Version:** 0.3.0  
**Date:** 2026-08-04  
**Status:** FROZEN_FOR_IMPLEMENTATION_PLANNING

## 1. Product experience thesis

The product behaves as a **longitudinal scientific measurement workstation with an always-available evidence-aware assistant**.

The practitioner is not primarily trying to browse charts or converse with an AI. The practitioner is trying to understand repeated CMJ measurements across time, determine whether sessions are valid and comparable, quantify change relative to an explicit reference model, inspect uncertainty, and record an accountable human decision.

The main screen therefore answers:

1. What changed across the selected athlete or cohort?
2. What reference model is being used?
3. Does the interpretation change under different rolling windows?
4. Which qualified metrics require attention?
5. Which measurement cases remain unresolved?
6. What evidence supports every displayed conclusion?

## 2. Identity hierarchy

### Current product

**Measurement Evidence Factory Agent**

Functional short label in the interface: **MEF Agent**.

### Future integrated system

**AgentSportsLab** is reserved for the future system that integrates multiple completed domain agents. It must not be used as the current application title.

## 3. Supported first vertical slice

- Athlete, not patient.
- Force plates, not generic devices.
- Bilateral unloaded hands-on-hips CMJ.
- Single total vertical force or dual independent vertical force only when qualified.
- Explicit sampling-rate and configuration contract.
- Native vendor export ingestion.
- Predetermined qualified CMJ metric pack.
- Athlete-specific longitudinal reference and uncertainty.
- Evidence-backed practitioner review.

## 4. Global application shell

The core desktop shell contains:

- Persistent left navigation.
- Context header.
- Main evidence workspace.
- Contextual action/status rail.
- Persistent MEF Agent dock.

The assistant is always reachable on every core screen, but remains visually and operationally secondary to the scientific workspace.

### Global navigation

1. Overview
2. Tests
3. Athletes
4. Force Plates & Imports
5. Evidence
6. Reports
7. Protocols & References
8. Settings

## 5. Overview dashboard

### Purpose

Provide a configurable longitudinal overview of accepted and unresolved repeated CMJ measurements.

### Persistent selectors

- Athlete, squad, position group, or cohort.
- Assessment family.
- Protocol.
- Force-plate configuration.
- Time range.
- Dashboard profile.
- Baseline/reference model.

### Baseline/reference model selector

The visible control label is **Baseline / Reference**. The domain object is `ReferenceModel`.

Supported reference types:

- Fixed reference epoch.
- Rolling 7 days.
- Rolling 14 days.
- Rolling 28 days.
- Rolling 30 days.
- Rolling 90 days.
- Rolling 3 accepted sessions.
- Rolling 5 accepted sessions.
- Rolling 10 accepted sessions.
- Custom calendar window.
- Custom accepted-session window.

The UI always displays the actual number of comparable sessions and valid trials included. A calendar window never implies that a sufficient number of observations exists.

### Dashboard anatomy

1. Context and reference controls.
2. Configurable qualified metric cards.
3. Primary longitudinal metric workspace.
4. Multi-window comparison panel.
5. Review and attention queue.
6. Evidence and data-quality status strip.
7. Persistent MEF Agent dock.

### Longitudinal metric workspace

The main visualization displays:

- Accepted session estimates.
- Selected reference estimate.
- Measurement-variation or uncertainty interval.
- Registered practical threshold where available.
- Protocol/configuration regime changes.
- Excluded or noncomparable sessions.
- Retest events.
- Practitioner annotations and approved milestones.

### Multi-window comparison

The same qualified metric may be compared under fixed, 7-day, 14-day, 28-day, and 30-day reference models. The interface explains that these are distinct comparison definitions, not competing truths.

### Configurable metric cards

Cards are selected only from the active qualified metric pack. The practitioner may configure visibility, order, density, and display type. The practitioner may not define arbitrary formulas.

Initial CMJ candidates:

- Impulse-momentum jump height.
- Takeoff velocity.
- Net vertical impulse.
- Contraction time.
- Countermovement displacement.
- Within-session variation.
- Valid-trial count.
- Session comparability.
- Baseline maturity.

### Attention queue

The dashboard surfaces unresolved measurement work:

- Trial review required.
- Retest required.
- Insufficient baseline.
- Protocol mismatch.
- Force-plate configuration change.
- Sampling-rate incompatibility.
- Missing metadata.
- Practitioner override awaiting completion.
- Inference unavailable or failed.

## 6. Dashboard profiles

Profiles alter information priority, not scientific computation.

Supported profile concepts:

- Performance monitoring.
- Longitudinal development.
- Return-to-participation measurement support.
- Research and validation.
- Custom practitioner profile.

A profile controls default metric prominence, reference policy, chart composition, queue emphasis, milestone visibility, and report template. It does not silently alter metric definitions, processing versions, or evidence eligibility.

### Return-to-participation safety boundary

The UI may support measurement milestones and practitioner-authored criteria during return-to-practice, return-to-training, return-to-sport, or return-to-competition workflows. It may not state that an athlete is healed, safe, cleared, ready, or at low injury risk.

Preferred wording:

- "Measurement criterion met under the selected contract."
- "Practical interpretation remains uncertain."
- "Practitioner review required."

Forbidden wording:

- "Cleared to compete."
- "Injury healed."
- "Readiness: red/green."
- "Fatigue detected."

## 7. Tests

### Test session registry

The table includes:

- Athlete.
- Session date/time.
- Protocol.
- Force-plate configuration.
- Sampling rate.
- Valid-trial count.
- Processing status.
- Comparability status.
- Reference eligibility.
- Practitioner decision.

### Metric Explorer

The Metric Explorer is the primary longitudinal analysis workspace inside Tests.

Permitted X-axis modes:

- Assessment date/time.
- Accepted-session index.
- Days since approved milestone.
- Sessions since reference epoch.

Permitted Y-axis modes:

- One metric in native units.
- Multiple synchronized native-unit panels.
- Relative change from the selected reference.
- Athlete-specific standardized difference.
- Probability relative to a registered practical threshold.
- Maximum two-metric dual-axis comparison with explicit warning.

The interface must not place arbitrary incompatible units on one undifferentiated axis.

### Metric Explorer interactions

- Select/deselect qualified metrics.
- Change X-axis mode.
- Change reference model.
- Toggle accepted, excluded, and noncomparable sessions.
- Show/hide uncertainty.
- Show/hide practical thresholds.
- Add practitioner annotations.
- Open a test-detail workspace from a plotted observation.
- Save a view to the active dashboard profile.

## 8. Test-detail workspace

Opening one session provides guided, revisitable stages:

1. Source
2. Configuration
3. Protocol
4. Trials
5. Session
6. Change
7. Decision
8. Evidence

The stage model is not a rigid wizard. Practitioners may revisit prior evidence while unresolved requirements remain visible.

### Trial review

The trial workspace includes:

- Left, right, and total vertical-force traces as available.
- Raw/processed signal state.
- Body-weight region.
- Movement onset.
- Takeoff.
- Landing.
- Phase markers used by the qualified processor.
- Quality flags.
- Trial inclusion/exclusion status.
- Predetermined metric observations.

Any human event adjustment or inclusion override must preserve the original value, require a reason, recalculate through the deterministic processor, and create a new evidence event.

### Session adjudication

Permitted dispositions:

- Accept as comparable.
- Accept as noncomparable context.
- Retest.
- Reject session.
- Escalate for expert review.
- Override with attributed rationale.

## 9. Force Plates & Imports

This area contains only force-plate acquisition and export workflows.

Functions:

- Upload supported native vendor export.
- Preserve original artifact and file hash.
- Detect export schema.
- Map source columns.
- Classify raw versus vendor-derived values.
- Resolve units and axes.
- Resolve single/dual plate configuration.
- Confirm sampling frequency and synchronization.
- Record calibration and zeroing metadata.
- Show adapter support and scientific qualification status.
- Block unsupported or unresolved imports visibly.

No unrelated device family may appear as an active product capability.

## 10. Athletes

Athlete pages provide:

- Repeated CMJ history.
- Current approved reference epochs.
- Baseline maturity.
- Assessment cases and decisions.
- Practitioner annotations.
- Evidence history.
- MEF Agent case and athlete memory review.

The athlete overview must not collapse history into a readiness score.

## 11. Evidence

The evidence experience supports drill-down from interpretation to source:

Interpretive statement -> inference result -> reference sessions -> session estimate -> trial metrics -> detected events -> canonical force signal -> original vendor artifact.

Evidence records include:

- Source artifact and hash.
- Adapter and mapping version.
- Canonical acquisition.
- Protocol and configuration contract.
- Processor and metric-pack version.
- Trial/event calculations.
- Session estimate.
- Reference model.
- Inference result and diagnostics.
- Human decision and overrides.
- Replay and audit history.

## 12. Reports

Reports are generated from accepted evidence records, not from arbitrary visible dashboard state.

Initial templates:

- Individual CMJ measurement report.
- Longitudinal change report.
- Reference-epoch report.
- Session quality report.
- Return-to-participation measurement report.
- Cohort summary.
- Evidence and audit report.

Every report identifies protocol, configuration, sampling rate, metric-pack version, reference definition, uncertainty, limitations, and practitioner authorship.

## 13. Protocols & References

Authorized users manage:

- Approved CMJ protocols.
- Force-plate acquisition contracts.
- Qualified sampling rates.
- Metric packs.
- Reference policies.
- Fixed reference epochs.
- Registered practical thresholds.
- Supported population declarations.
- Evidence-tier visibility.

## 14. Settings

### Dashboard configuration

- Default dashboard profile.
- Visible metric cards.
- Card order and density.
- Default time range.
- Default reference model.
- Default Metric Explorer mode.
- Queue modules and annotations.

### Assistant configuration

- Docked/collapsed preference.
- Explanation depth.
- Default memory scope.
- Workspace terminology.
- Memory inspection and deletion.

### Scientific policy

Restricted to authorized roles. Scientific policy changes are versioned and auditable.

## 15. Persistent MEF Agent

The same assistant appears on every core screen.

### Required continuity

- Same identity and tone.
- Durable conversation continuity.
- Visible current context.
- Case-level thread persistence.
- Bounded athlete/workspace memory.
- Evidence-linked answers.
- Structured action proposals.

### Visible context

The panel displays current:

- Workspace.
- Athlete or cohort.
- Test case.
- Screen.
- Selected metric, trial, or evidence object.
- Reference model.
- Dashboard profile.

### Agent capabilities

- Explain verified results and quality flags.
- Summarize differences between reference windows.
- Locate supporting evidence.
- Navigate to relevant objects.
- Request missing metadata.
- Draft practitioner notes and retest rationale.
- Prepare structured actions for human confirmation.

### Prohibitions

The agent cannot:

- Perform hidden scientific calculations.
- Define or alter metric formulas.
- Change processing thresholds.
- Approve a trial or session.
- Change a baseline silently.
- Set a practical threshold without authorized human action.
- Diagnose injury or fatigue.
- infer unsupported training causality.
- issue readiness or clearance labels.

## 16. Visual system baseline

The functional UI baseline is a dense, calm scientific operations console.

- Desktop-first.
- Dark-first prototype direction with neutral graphite/navy surfaces.
- Blue primary actions.
- Amber unresolved/review states.
- Red invalid/unsupported states.
- Green confirmed/accepted workflow states only.
- Violet reserved for assistant context and human override emphasis.
- High-information-density tables and charts.
- Minimal decorative animation.
- Monospaced treatment for IDs, versions, hashes, and exact measurements where useful.

Exact color values and typography remain implementation-level tokens rather than frozen scientific requirements.

## 17. Responsive baseline

- Primary target: 1440 px desktop.
- Standard laptop: 1280 px.
- Minimum supported core workspace: 1024 px.
- On narrower widths, the assistant becomes an overlay drawer and the action rail stacks.
- Mobile-native workflows are excluded from MVP.

## 18. Accessibility

- Full keyboard navigation.
- Visible focus states.
- Semantic tables and forms.
- Text alternatives for chart conclusions and active filters.
- Color-independent state communication.
- Accessible assistant dock and conversation history.
- No evidence interpretation conveyed by color alone.

## 19. Critical UX invariants

1. The product name is Measurement Evidence Factory Agent.
2. AgentSportsLab is not shown as the current product.
3. Force plates and CMJ are the only active first-release device/test family.
4. Overview is longitudinal and reference-centered.
5. Every comparison identifies its reference definition and observation count.
6. Dashboard metrics come only from a qualified metric pack.
7. Unknown values never appear confirmed.
8. Machine result and human decision remain visually distinct.
9. Overrides preserve original results.
10. Every interpretive statement links to evidence.
11. Measurement uncertainty and practical importance remain separate.
12. The persistent MEF Agent appears on every core screen.
13. The agent displays its active context.
14. No readiness, fatigue, injury, diagnosis, clearance, or unsupported causal label appears.
15. Original vendor artifacts remain reachable.

## 20. Definition of UX implementation complete

The first executable UX slice is complete when a practitioner can:

- Open the longitudinal Overview.
- Change fixed and rolling reference models.
- Configure visible qualified metric cards.
- Inspect multi-window metric changes.
- Enter Tests and use the Metric Explorer.
- Open one CMJ session.
- Traverse source, configuration, protocol, trials, session, change, decision, and evidence.
- Upload one supported force-plate export.
- See unsupported states fail visibly.
- Use the same persistent MEF Agent across navigation.
- Preserve and revisit the assistant thread.
- Record a human disposition without erasing machine evidence.
