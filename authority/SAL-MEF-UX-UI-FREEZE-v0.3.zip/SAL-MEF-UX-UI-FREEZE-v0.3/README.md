# Measurement Evidence Factory Agent UX/UI Freeze Bundle

This bundle freezes the first product experience for the force-plate CMJ Measurement Evidence Factory Agent.

## Primary documents

- `SAL-MEF-UX-UI-DESIGN-FREEZE-v0.3.md`
- `SAL-MEF-UX-UI-DESIGN-FREEZE-v0.3.docx`
- `SAL-MEF-UX-UI-DESIGN-FREEZE-v0.3.pdf`
- `FREEZE_RECORD.md`
- `IMPLEMENTATION_SEQUENCE_DECISION_BRIEF.md`

## Contracts

- Information architecture and routes.
- Screen registry.
- Persistent MEF Agent UX and memory.
- Measurement-case state model.
- UX implementation acceptance gates.

## Machine-readable schemas

- Navigation contract.
- Dashboard profile schema.
- Assistant context schema.
- Screen state registry.
- Freeze manifest.

## Diagrams

- Information architecture.
- Overview dashboard anatomy.
- Test-detail workflow and persistent agent context.

## Authority

This bundle freezes experience architecture, not scientific formulas or final pixel polish. The product is the Measurement Evidence Factory Agent. AgentSportsLab is the future integrated multi-agent system.
