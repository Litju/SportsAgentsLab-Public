# Implementation Sequence Decision Brief

This document intentionally does not select the implementation sequence. It defines the three credible starting strategies for the next owner decision.

## Option A - UI-first executable shell

Start with the global shell, Overview, Tests registry, Metric Explorer, test-detail routes, and persistent MEF Agent using typed fixtures.

Strengths:

- Validates the product workflow immediately.
- Produces a visible vertical slice.
- Forces domain contracts to become concrete.
- Enables early practitioner feedback.

Risks:

- Mocked scientific behavior may accidentally harden into the architecture.
- UI contracts can drift from the eventual processor and evidence model.
- Early visual progress may hide missing scientific foundations.

## Option B - Software-factory-first

Start with source adapters, canonical acquisition, force-plate configuration contracts, deterministic CMJ processor boundary, metric-pack registry, reference model, inference port, provenance, and evidence authority.

Strengths:

- Establishes scientific and evidentiary authority first.
- Reduces risk of UI-led domain distortion.
- Creates reusable framework-neutral services.
- Makes later UI data real and replayable.

Risks:

- Delays practitioner-visible learning.
- Can overengineer scientific machinery before workflow validation.
- Makes it easier to build infrastructure without a compelling product experience.

## Option C - Thin-slice co-development

Build one narrow end-to-end path with typed contracts on both sides:

- One native export fixture.
- One qualified acquisition configuration.
- One CMJ protocol.
- One small metric pack.
- One reference model.
- One evidence record.
- Overview and one test-detail workflow.
- Persistent MEF Agent invoking mocked or early qualified services behind stable ports.

Strengths:

- Maintains product and scientific feedback together.
- Avoids broad UI mockware and broad backend infrastructure.
- Reveals contract mismatches early.

Risks:

- Requires strict scope control.
- Can become messy without explicit ownership and gates.
- Needs a disciplined fixture-to-qualified-service replacement plan.

## Decision criteria

Score each option against:

- Scientific risk.
- Product-learning speed.
- Architecture reversibility.
- Founder motivation and visible progress.
- Availability of representative raw exports.
- Readiness of the CMJ deterministic contract.
- Ability to prevent mocked behavior from entering production authority.
- Ease of independent validation.

The owner should select the sequence only after reviewing the frozen UX contract and the current maturity of the scientific factory specifications.
