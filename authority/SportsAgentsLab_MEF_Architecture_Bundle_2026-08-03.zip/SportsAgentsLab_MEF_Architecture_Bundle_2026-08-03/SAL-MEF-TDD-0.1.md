---
title: "Technical Design Document (TDD)"
subtitle: "SportsAgentsLab Measurement Evidence Factory"
author: "SportsAgentsLab"
date: "2026-08-03"
lang: en-US
---

# Technical Design Document (TDD)

**Document ID:** `SAL-MEF-TDD-0.1`  
**Version:** `0.1.0`  
**Status:** `CURATED_BASELINE_FOR_OWNER_REVIEW`  
**Research freeze:** 2026-08-03  
**Implementation authority:** Not granted by this document  
**Purpose:** Define the implementable architecture, technology baseline, service boundaries, contracts, data topology, workflows, security, observability, testing, release machinery, and deployment plan.

> **Normative language.** “MUST”, “MUST NOT”, “SHOULD”, “SHOULD NOT”, and “MAY” are used as requirements terms. A requirement is not scientifically qualified merely because it appears here. Scientific claims advance only through the defined evidence gates.

> **Safety boundary.** The system does not diagnose injury, infer unsupported training causality, clear an athlete, prescribe medical action, or conceal uncertainty behind generic readiness labels. Qualified practitioners retain final interpretation.


## 1. Technical decision summary

The selected baseline is a **modular monorepo with a TypeScript control plane and isolated Python scientific plane**, deployed initially as a small number of containerized services. It avoids both a single-language compromise and premature microservice sprawl.

- **Control plane:** Node.js 24 LTS, TypeScript 5.9 compatibility baseline, strict compiler settings, Next.js/React practitioner UI, Fastify control API, generated OpenAPI/JSON Schema clients.
- **Scientific plane:** CPython 3.13.14 production baseline, Python 3.14.6 qualification lane, NumPy/SciPy/PyArrow, FastAPI/Pydantic boundary APIs, pure deterministic kernels, PyMC 6.2 primary model-development candidate, CmdStan/Stan 2.39 independent oracle.
- **Workflow:** Temporal for durable system workflows; Eve behind a framework-neutral agent-runtime adapter.
- **Operational state:** PostgreSQL 18.4.
- **Immutable data:** S3-compatible object storage; Apache Parquet and Arrow for canonical signals.
- **Contracts:** JSON Schema 2020-12 as domain schema authority; OpenAPI 3.2 where tooling passes, with 3.1 compatibility projection if required.
- **Provenance/evidence:** W3C PROV specialization, RO-Crate 1.2 / Workflow Run RO-Crate export, canonical JSON, SHA-256, DSSE/in-toto-style attestations, Sigstore Cosign for release signing.
- **Observability:** OpenTelemetry/OTLP for traces, metrics, and logs.
- **Security:** OIDC, organization-scoped RBAC plus purpose/context attributes, PostgreSQL row-level security, NIST SSDF 1.1, OWASP ASVS 5.0, OWASP LLMSVS 2.0 for the agent surface.
- **Delivery:** GitHub Actions, `uv` and locked Python environments, `pnpm`, OCI images, SBOM, SLSA provenance, cosign signatures, progressive deployment.

The exact dependency versions are lockfile decisions and must pass the compatibility matrix. Latest is not automatically safest: TypeScript 6.0 is a transition release and Python 3.14 is qualified before becoming the scientific production baseline [W22-W24].

![Container architecture](diagrams/container_architecture.png){width=100%}

## 2. Architecture drivers

| Driver | Technical response |
| --- | --- |
| Scientific independence | Pure Python kernel and CLI, no Eve/LLM/web dependency. |
| Vendor independence | Adapter ports and canonical acquisition schema. |
| Configuration/sample-rate specificity | Exact configuration-contract resolver and eligibility policy. |
| Reproducibility | Content-addressed inputs, immutable releases, locked dependencies, replay manifests. |
| Human authority | Durable approval tasks and append-only decision history. |
| Evidence portability | RO-Crate profile, JSON/Parquet artifacts, verifier CLI. |
| Small-team maintainability | Modular monolith, generated contracts, limited deployables, managed infrastructure. |
| Scale path | Stateless workers, object storage, Temporal task queues, partitionable Postgres. |
| Security and privacy | Data minimization, tenant isolation, RLS, scoped credentials, encrypted object storage. |
| Framework churn | Ports/adapters around Eve, workflow, storage, and statistical runtimes. |

## 3. System context and trust boundaries

The control plane is user-facing and authority-bearing. The scientific plane is computation-bearing. The evidence authority is verification-bearing. The agent plane is coordination-bearing. None can unilaterally create a practitioner-accepted scientific claim.

### 3.1 Trust boundaries

1. **External source boundary:** untrusted vendor files and metadata.
2. **Canonicalization boundary:** only validated typed acquisitions pass inward.
3. **Scientific execution boundary:** network-restricted, read-only inputs, immutable outputs.
4. **Evidence boundary:** verification of manifests, release eligibility, signatures, and policy.
5. **Human authority boundary:** explicit authenticated decision.
6. **LLM boundary:** minimized structured context; no raw high-rate signal by default.

## 4. Repository and module topology

```text
sports-measurement-evidence-factory/
├── apps/
│   ├── practitioner-web/          # Next.js / React
│   ├── control-api/               # Fastify / TypeScript
│   └── verifier-cli/              # TS or Python thin client
├── services/
│   ├── scientific-api/            # FastAPI orchestration boundary
│   ├── adapter-worker/            # source parsing/canonicalization
│   ├── processor-worker/          # deterministic force-plate kernel
│   ├── inference-worker/          # statistical packs
│   └── evidence-worker/           # crate assembly and verification
├── packages/
│   ├── schemas/                   # JSON Schema source authority
│   ├── generated-ts/              # generated, never hand-edited
│   ├── generated-python/          # generated, never hand-edited
│   ├── control-domain/            # TS application/domain modules
│   ├── agent-runtime-port/        # framework-neutral interfaces
│   ├── eve-runtime-adapter/       # optional beta adapter
│   ├── policy/                    # authorization/evidence policies
│   └── ui-components/
├── scientific/
│   ├── acquisition/               # canonical models and units
│   ├── forceplate/                # small deterministic kernel
│   ├── cmj/                       # protocol/event/metric definitions
│   ├── inference/                 # model specifications
│   ├── provenance/                # run manifests
│   └── reference_oracles/         # independent implementations
├── registry/
│   ├── adapters/
│   ├── configurations/
│   ├── protocols/
│   ├── metric-packs/
│   ├── reliability-profiles/
│   ├── inference-packs/
│   └── policies/
├── tests/
│   ├── fixtures/
│   ├── golden/
│   ├── adversarial/
│   ├── contracts/
│   └── end-to-end/
├── evidence-profiles/
├── infra/
└── docs/
```

### 4.1 Boundary rules

- `scientific/*` cannot import from `apps/*`, Eve, Temporal SDK, database ORM, or web frameworks.
- Worker adapters may import the scientific library, not the inverse.
- TypeScript and Python types are generated from schemas; hand-written duplicate contracts fail CI.
- Released registry objects are data artifacts, not mutable application rows.
- Scientific functions accept immutable typed values and return explicit result/error unions.
- Architecture tests enforce allowed dependency edges.

## 5. Technology baseline and rationale

| Layer | Selected baseline | Rationale | Qualification caveat |
| --- | --- | --- | --- |
| Frontend | Next.js + React + TypeScript | Mature ecosystem, accessible data-review UI, strong server/client integration. | Freeze exact supported versions; avoid framework-specific scientific logic. |
| Control API | Fastify on Node 24 LTS | Small, fast, schema-oriented, lower ceremony than a large framework. | Security middleware and organization conventions must be curated. |
| Type system | TypeScript 5.9 strict initial baseline | Broad dependency compatibility; valid-state modeling and generated types [S11]. | Test TypeScript 6.0 separately before promotion. |
| Scientific runtime | CPython 3.13.14 | Conservative compatibility for NumPy/SciPy/PyMC ecosystem. | Python 3.14.6 runs in CI qualification lane. |
| Scientific arrays | NumPy/SciPy | Standard audited numerical substrate; aligns with Python scientific practice [S10]. | Pin BLAS/runtime; test numerical tolerances across platforms. |
| Columnar I/O | PyArrow / Parquet | Typed, cross-language, compact high-rate signal storage [W20]. | Schema evolution and floating-point encoding tests required. |
| Python boundary API | FastAPI + Pydantic v2 | Typed validation, OpenAPI generation, mature Python integration [W25]. | Scientific kernel stays independent of these frameworks. |
| Operational DB | PostgreSQL 18.4 | Transactions, constraints, JSONB, RLS, mature operations [W21]. | Use managed service initially; version upgrade rehearsals. |
| Object store | S3-compatible managed storage | Immutable large artifacts, lifecycle, retention, replication. | Do not make proprietary object APIs part of domain contracts. |
| Workflow | Temporal | Durable retries, timers, approvals, and long waits [W28]. | Start only after workflow complexity justifies it; retain workflow port. |
| Agent runtime | Eve adapter candidate | Durable sessions, approvals, traces, typed tools [W01]. | Beta; production adoption only after spike. |
| Bayesian engine | PyMC primary candidate | Python-native model development and diagnostics [W26]. | Model-by-model benchmark; not a blanket mandate. |
| Independent oracle | CmdStanPy / Stan 2.39 | Independent implementation and mature diagnostics [W27]. | C++ toolchain and compile cost; primarily qualification/replay. |
| Observability | OpenTelemetry / OTLP | Vendor-neutral traces, metrics, logs [W29]. | Telemetry cannot contain raw sensitive signal by default. |
| Signing | Sigstore Cosign + DSSE/in-toto predicates | Verifiable release and attestation chain [W10, W11]. | Offline/private deployment needs key-management profile. |

## 6. Contract system

### 6.1 Schema authority

JSON Schema 2020-12 is the source authority for domain payloads [W18]. Schemas use stable IDs, semantic versions, explicit units/quantities, closed discriminated unions where possible, and compatibility metadata. Generated TypeScript/Python types are build artifacts. This follows the Effective TypeScript guidance to derive types from official schemas rather than anecdotal sample data [S11].

### 6.2 API description

OpenAPI 3.2 is the desired external API description [W19]. Because ecosystem support may lag, CI must generate and test a 3.1-compatible projection before 3.2 becomes mandatory. The domain schema remains authoritative, preventing API-tool limitations from changing scientific semantics.

### 6.3 Identifier strategy

- UUIDv7 for operational identities and sortable event IDs.
- SHA-256 content digests for immutable artifacts.
- Stable namespaced IDs for scientific definitions, e.g. `sal.metric.cmj.jump_height_impulse_momentum`.
- Semantic version for declared compatibility; content digest for exact identity.
- Run identity = hash of source artifact, mapping, configuration, protocol, processor, metric pack, inference pack, and policy references.

### 6.4 Quantity representation

```json
{
  "value": 0.4123,
  "unit": "m",
  "quantity_kind": "length",
  "uncertainty": null,
  "source": "metric_observation:..."
}
```

UCUM codes are used at interfaces [W17]. Internally, dimensional types/wrappers prevent mixing force, mass, weight, time, and velocity. Floating-point values are never compared with unqualified exact-equality rules except where serialization identity is intended.

## 7. Data architecture

### 7.1 PostgreSQL responsibilities

PostgreSQL stores organizations, identities, roles, source registrations, import attempts, canonical-acquisition metadata, sessions, trials, registry indexes, workflow state references, evidence statuses, decisions, and audit events. It does not store every high-rate sample as one row.

### 7.2 Object-store responsibilities

- exact native source artifacts;
- canonical `signals.parquet` files;
- mapping records and schemas;
- deterministic traces and metric outputs;
- posterior draws or compressed inference artifacts where required;
- RO-Crate evidence bundles;
- SBOMs, build attestations, signatures, and validation reports.

Objects are written once to content-derived or immutable versioned keys. Retention, legal hold, and deletion policy are stored separately from scientific identity.

### 7.3 Canonical acquisition package

```text
acquisition/<acquisition-id>/
├── acquisition.json
├── signals.parquet
├── mappings.json
├── quality-at-import.json
├── source-ref.json
└── checksums.json
```

`signals.parquet` uses one time column plus strongly typed channel columns for each platform/quantity. Metadata contains channel IDs, source columns, units, scale/offset, axis transform, calibration reference, timestamp mode, and missingness. Original sample order is retained.

### 7.4 Database constraints

- source digest unique within an organization unless explicit duplicate import is recorded;
- scientific release rows immutable after release status;
- accepted decisions cannot be updated, only superseded by a new decision event;
- RLS policies require organization and purpose context;
- foreign keys bind every result to exact contract versions;
- evidence status transitions use validated state-machine functions.

## 8. Service and component design

### 8.1 Control API

Responsibilities: authentication, authorization, tenant context, upload initiation, workflow commands, review queries, decisions, exports, and agent tool gateway. It never performs scientific arithmetic.

Modules:

- Identity and organization.
- Assessment intake.
- Configuration review.
- Session and trial review.
- Reference epoch and SESOI governance.
- Evidence query and decision.
- Scientific registry read model.
- Agent tool gateway.
- Audit and export.

### 8.2 Adapter worker

Each adapter is a plugin with:

```python
class SourceAdapter(Protocol):
    manifest: AdapterManifest
    def inspect(self, artifact: ArtifactRef) -> SourceSchemaObservation: ...
    def parse(self, artifact: ArtifactRef, mapping: MappingContract) -> CanonicalAcquisitionDraft: ...
    def verify(self, draft: CanonicalAcquisitionDraft) -> ImportVerification: ...
```

The worker runs in a constrained container, treats files as hostile, enforces size/row/column limits, disables formulas/macros for spreadsheet inputs, and never imports vendor-derived metrics as raw sensor channels.

### 8.3 Configuration resolver

Resolution is rule-based and registry-backed. It evaluates required channels, timing, source state, geometry/calibration, synchronization, preprocessing, and supported equivalence. No fuzzy LLM classification is allowed. Human review resolves only explicitly exposed unknown/conflict fields.

### 8.4 Deterministic processor

The kernel is a pure library with the layers below:

1. Structural validation.
2. Signal integrity checks.
3. Quantity/unit and coordinate normalization.
4. Quiet-standing/body-weight estimation.
5. Protocol-specific event detection.
6. Phase segmentation.
7. Primitive mechanics: net force, acceleration, integration, displacement, impulse.
8. Metric-definition execution.
9. Trial-quality adjudication.
10. Calculation trace emission.

Bruce’s model-based framing is binding: the processor documents the assumptions under which a transform separates desired signal and noise, and it evaluates indicators that the chosen model is inadequate [S06]. Adaptive or data-driven filtering is not introduced merely because it is available; nonstationary methods require separate evidence [S08].

### 8.5 Numerical policy

- `float64` is the baseline scientific numeric type.
- Timestamps are integer nanoseconds from acquisition origin where source precision supports it.
- Integration uses declared algorithms and sample intervals, not index-count assumptions.
- Gravity is an explicit protocol/processor parameter, defaulting to the frozen conventional value only when approved.
- Numerical tolerances are named and dimensioned.
- No global mutable configuration.
- BLAS and CPU differences are tested for tolerance, not assumed bitwise-identical.
- Deterministic release containers pin OS, Python, numeric libraries, and relevant CPU settings.

### 8.6 Metric-pack runtime

A metric pack manifest is data, but formulas are code-backed entry points. Dynamic expression evaluation is forbidden.

```yaml
id: sal.metricpack.cmj.vertical_core
version: 1.0.0
protocol: sal.protocol.cmj.bilateral.unloaded.hoh@1
eligible_configurations:
  - sal.config.single.total_fz.1000hz@1
  - sal.config.dual.independent_fz.1000hz@1
processor_release: sha256:...
primary_inferential_metric:
  - sal.metric.cmj.jump_height_impulse_momentum@1
descriptive_metrics:
  - sal.metric.cmj.takeoff_velocity@1
  - sal.metric.cmj.contraction_time@1
  - sal.metric.cmj.net_vertical_impulse@1
aggregation:
  valid_trials_required: 3
  estimator: arithmetic_mean
```

The runtime validates all prerequisites before importing the referenced function. An unknown metric ID, version, or code digest fails closed.

## 9. Statistical inference design

### 9.1 Estimand first

The initial estimand is the athlete’s latent current session performance relative to a practitioner-approved comparable reference epoch for one qualified metric. The system is not estimating “readiness”, “fatigue”, or causal training response.

### 9.2 Candidate model

For positive metrics, a log-scale hierarchical measurement model is the preferred candidate:

```text
log(y_i,s,r) = theta_i,s + epsilon_i,s,r

epsilon ~ Student-t(0, sigma_within, nu)
theta_i,s ~ Normal(mu_i, sigma_between)
```

Population, organization, device, or sex effects are not included by default. Each added hierarchy requires a design, identifiability argument, and validation. Partial pooling can stabilize sparse baselines but cannot disguise unsupported subgroup assumptions.

### 9.3 Engine strategy

- **Analytic/simple baseline:** implement first where exact or well-understood approximations suffice.
- **PyMC candidate:** primary authoring and production candidate after benchmark [W26].
- **Stan oracle:** independent model implementation and diagnostics comparison [W27].
- **ArviZ-compatible artifacts:** diagnostics and posterior summaries.

Promotion requires agreement of estimands, simulations, interval calibration, diagnostics, and failure behavior. The framework is replaceable through an `InferenceRuntime` port.

### 9.4 Required diagnostics

- prior predictive checks;
- simulation-based calibration where applicable;
- convergence/R-hat and effective sample size;
- divergences and energy diagnostics for HMC;
- posterior predictive checks;
- coverage on synthetic known-truth data;
- sensitivity to priors, reference sessions, outliers, and missing trials;
- subgroup calibration;
- comparison against simpler classical/analytic baselines.

### 9.5 Output schema

```json
{
  "estimand": "current_minus_reference_log_scale",
  "current_estimate": {"value": 0.413, "unit": "m"},
  "reference_estimate": {"value": 0.429, "unit": "m"},
  "absolute_change": {"value": -0.016, "unit": "m"},
  "relative_change": -0.037,
  "interval_90": [-0.025, -0.006],
  "interval_95": [-0.028, -0.003],
  "probability_decrease": 0.982,
  "sesoi": null,
  "practical_interpretation": "UNAVAILABLE_NO_REGISTERED_SESOI",
  "diagnostic_status": "PASS",
  "pack_digest": "sha256:..."
}
```

## 10. Provenance, evidence, and signing

### 10.1 Provenance graph

Entities: source artifact, canonical acquisition, contracts, processor build, metric observations, inference artifacts, evidence manifest, decision. Activities: import, normalize, resolve, process, aggregate, infer, assemble, verify, adjudicate. Agents: adapter, worker, CI builder, reviewer, practitioner, organization, agent runtime. This is represented through a SportsAgentsLab profile of W3C PROV [W12].

### 10.2 Canonical manifest and digest

Evidence manifests are serialized with a canonical JSON scheme such as RFC 8785/JCS before hashing. Every artifact entry contains media type, length, SHA-256 digest, logical role, and provenance relation. The manifest itself is hashed and signed.

### 10.3 Attestations

- Build attestation: source, builder, invocation, materials, subject digest, SBOM.
- Scientific qualification attestation: object ID, evidence tier, supported scope, tests, reviewer, limitations.
- Runtime attestation: exact inputs, releases, outputs, environment, run ID.
- Practitioner decision attestation: actor, role, evidence manifest, disposition, reason, time.

SLSA encourages explicit attestations and isolated build platforms; Sigstore bundles signatures, certificates, timestamps, and transparency evidence [W10, W11, S12]. Private deployments may use organization-managed keys and an offline transparency profile.

### 10.4 Evidence verifier

A standalone verifier CLI must:

1. validate crate structure and schemas;
2. recompute artifact digests;
3. verify release and run attestations;
4. resolve registry objects or bundled manifests;
5. enforce scope and lifecycle policy;
6. replay deterministic processing when requested;
7. compare replay output to recorded result;
8. report missing, invalid, deprecated, or untrusted evidence;
9. never require Eve or the practitioner web application.

## 11. Workflow design

### 11.1 Durable workflow

Temporal workflows coordinate multi-step execution, retries, timeouts, and human waits [W28]. Activities contain side effects; workflows contain deterministic orchestration. Scientific computations are activities that reference immutable inputs and are idempotent by run key.

Core workflows:

- `IngestArtifactWorkflow`
- `ResolveConfigurationWorkflow`
- `ProcessAssessmentWorkflow`
- `RunInferenceWorkflow`
- `AssembleEvidenceWorkflow`
- `PractitionerReviewWorkflow`
- `QualifyScientificObjectWorkflow`

### 11.2 Human task pattern

A missing-metadata or approval task contains exact question, required role, allowed responses, evidence context, expiry, and escalation. The workflow sleeps durably until a signed response arrives. Expired or changed evidence invalidates the task rather than applying stale approval.

### 11.3 Agent-runtime port

```typescript
interface MeasurementAgentRuntime {
  startSession(input: StartSession): Promise<AgentSessionRef>;
  continueSession(input: ContinueSession): Promise<AgentTurn>;
  requestApproval(input: ApprovalRequest): Promise<ApprovalRef>;
  getTrace(ref: AgentSessionRef): Promise<AgentTraceRef>;
  cancel(ref: AgentSessionRef): Promise<void>;
}
```

The Eve adapter maps these methods to Eve sessions and approval actions. The system’s approval record remains in the control plane, not only inside Eve.

### 11.4 Agent tool gateway

Tools are narrow, typed, policy-checked, and idempotent:

- `inspect_source_artifact`
- `get_configuration_resolution`
- `submit_missing_metadata`
- `run_qualified_metric_pack`
- `run_qualified_inference_pack`
- `get_evidence_manifest`
- `request_practitioner_decision`
- `explain_verified_result`

No raw code execution, arbitrary SQL, arbitrary metric calculation, baseline editing, SESOI setting, scientific release signing, or evidence-tier upgrade tool is exposed.

## 12. API surface

| Method | Path | Purpose | Authority |
| --- | --- | --- | --- |
| POST | /v1/artifacts/uploads | Create pre-signed upload and source registration. | Operator |
| POST | /v1/imports | Start adapter inspection/import workflow. | Operator |
| GET | /v1/imports/{id} | Read source schema, mappings, warnings, resolution. | Authorized org user |
| POST | /v1/imports/{id}/mapping-decisions | Approve or reject exact mapping fields. | Qualified mapper |
| GET | /v1/acquisitions/{id} | Canonical acquisition metadata and artifact refs. | Authorized org user |
| POST | /v1/assessments | Create assessment/session under a protocol. | Operator |
| POST | /v1/assessments/{id}/process | Request eligible deterministic processing. | Operator / system |
| GET | /v1/assessments/{id}/trials | Trial QA, events, metrics, provenance. | Practitioner |
| POST | /v1/trials/{id}/decisions | Accept/exclude/retest with reason. | Practitioner |
| POST | /v1/reference-epochs | Create practitioner-approved reference epoch. | Practitioner |
| POST | /v1/inference-runs | Run eligible inference pack. | Practitioner / system |
| GET | /v1/evidence/{id} | Evidence manifest and verification state. | Authorized user |
| POST | /v1/evidence/{id}/decisions | Accept/override/retest/reject. | Practitioner |
| GET | /v1/registry/{kind}/{id} | Read released scientific manifest and scope. | Authenticated or public subset |
| POST | /v1/exports | Build authorized report/crate. | Authorized user |

All mutation endpoints require idempotency keys. Optimistic concurrency or expected-version headers prevent lost decisions. Errors are typed problem details with stable machine codes such as `UNSUPPORTED_SAMPLE_RATE`, `UNKNOWN_VENDOR_FILTER`, or `REFERENCE_REGIME_MISMATCH`.

## 13. Event and outbox design

PostgreSQL is the system of record. A transactional outbox publishes domain events after commit. Events are integration facts, not the sole database model.

Representative events:

- `SourceArtifactRegistered`
- `ImportSchemaObserved`
- `CanonicalAcquisitionCreated`
- `ConfigurationResolutionChanged`
- `TrialQualityComputed`
- `MetricObservationSetCreated`
- `ReferenceEpochApproved`
- `InferenceCompleted`
- `EvidenceVerified`
- `PractitionerDecisionRecorded`
- `ScientificReleaseDeprecated`

Consumers are idempotent and track event IDs. Event payloads contain references, not large signal arrays.

## 14. Security architecture

### 14.1 Identity and authorization

- OIDC authorization-code flow with PKCE for users.
- Short-lived workload identities for services.
- Organization membership and role stored in Postgres.
- RBAC for role capability; ABAC for purpose, athlete/cohort scope, evidence state, and action risk.
- PostgreSQL RLS as defense in depth.
- No long-lived credential in agent context.

### 14.2 File security

- Upload quarantine bucket/prefix.
- MIME and extension mismatch detection.
- CSV/XLSX/ZIP bomb limits, row/column limits, archive-depth limits.
- Formula/macros disabled; no office document execution.
- Malware scanning where deployment profile requires it.
- Parser sandbox with CPU, memory, wall-time, and filesystem limits.
- Content-derived identity prevents substitution after review.

### 14.3 Application security verification

The release checklist maps to NIST SSDF 1.1 and OWASP ASVS 5.0 [W05, W08]. Agent-specific controls map to OWASP LLMSVS 2.0 [W09], including prompt/tool boundary, data leakage, untrusted content, excessive agency, output verification, and denial-of-wallet controls.

### 14.4 Cryptography

- TLS 1.3 preferred in transit.
- Managed KMS encryption at rest.
- Envelope encryption for especially sensitive artifacts if required.
- SHA-256 minimum content digest.
- Separate signing identities for build, qualification, runtime, and practitioner authority.
- Key rotation does not change artifact identity; verification bundles preserve historic trust evidence.

## 15. Privacy and governance

- Data minimization: the LLM receives summaries/typed fields, not raw 1,000 Hz traces by default.
- Purpose binding: access token/session carries declared purpose.
- Retention and deletion operate on organization/athlete rights while preserving legally required audit stubs where applicable.
- Derived data and evidence link to source-purpose authorization.
- Training foundation models on athlete data is forbidden by default.
- Logs and telemetry exclude raw signals, names, free-text medical notes, and secrets.
- Deidentified validation corpora use separate governance and reidentification-risk review.

This is a product-control design, not jurisdiction-specific legal advice.

## 16. Observability and service-level objectives

OpenTelemetry supplies vendor-neutral instrumentation and OTLP export [W29]. Every request, workflow, activity, scientific run, and evidence assembly receives trace correlation IDs. Scientific spans record release IDs, durations, statuses, and artifact references, not raw values.

| SLI | MVP target | Alert / control |
| --- | --- | --- |
| API availability | 99.5% monthly | Burn-rate alerts; evidence exports remain independent. |
| Upload success | >=99% for supported files | Schema/error taxonomy reviewed weekly. |
| Deterministic processing latency | p95 <=10 s for typical 3-trial file | Queue and worker saturation alert. |
| Evidence assembly latency | p95 <=30 s excluding posterior refit | Object-store and signing errors. |
| Duplicate execution | 0 accepted duplicate result per idempotency key | Invariant alert. |
| Replay mismatch | 0 for released deterministic corpus | Release blocker. |
| Unauthorized access | 0 | Security incident. |
| Prohibited agent output | 0 severe | Runtime disable/incident review. |

## 17. Capacity and performance model

Initial design assumption:

- 100 organizations.
- 20,000 active athletes.
- 5 million trials/year.
- Median source file <10 MB; exceptional files bounded by policy.
- Scientific execution is bursty around testing windows.

Parquet/object storage scales independently from relational metadata. Workers scale on Temporal task-queue depth and CPU/memory. No Kubernetes is required initially; a managed container platform with autoscaling is sufficient. PostgreSQL uses connection pooling, indexed organization/time partitions where proven, and read replicas only when measurements show need.

Performance tests include large row counts, malformed long lines, high-cardinality metadata, concurrent uploads, queue bursts, evidence export, and slow signing/object storage.

## 18. Reliability, backup, and disaster recovery

- Multi-AZ managed PostgreSQL with point-in-time recovery.
- Versioned/immutable object storage with replication and deletion protection for accepted evidence.
- Temporal persistence backed by managed/high-availability database profile.
- Daily restore verification in non-production and quarterly full DR exercise.
- RPO: 15 minutes operational state; zero accepted immutable objects after successful write acknowledgment.
- RTO: 4 hours MVP.
- Evidence verifier and exported crates allow audit even during application outage.
- Workflow activities are idempotent; retry and compensation behavior is tested.

## 19. Testing and scientific qualification

### 19.1 Software test layers

| Layer | Tools / method | Purpose |
| --- | --- | --- |
| Static | mypy/pyright, Ruff, TypeScript strict, ESLint, dependency/architecture rules | Contract and dependency defects. |
| Unit | pytest, Vitest | Local logic and edge cases. |
| Property | Hypothesis / fast-check | Invariants across generated signals and schemas. |
| Golden corpus | Frozen native exports, canonical artifacts, events, metrics | Regression and replay. |
| Metamorphic | Known transformations with expected invariant or directional effect | Detect implementation errors without exact oracle. |
| Differential | Second implementation, Stan oracle, vendor comparison | Independent disagreement detection. |
| Contract | JSON Schema/OpenAPI consumer-provider tests | Cross-language and service compatibility. |
| Integration | Postgres, object storage, Temporal, signing, auth | Infrastructure boundaries. |
| End-to-end | Playwright and API workflows | Practitioner workflow and authority. |
| Security | SAST, SCA, secrets, container scan, ASVS tests, file fuzzing | Attack resistance. |
| Agent eval | Forbidden claims, tool authorization, missing metadata, restart/approval | Bounded behavior. |

### 19.2 Synthetic signal families

- Constant quiet standing with known body weight.
- Analytic piecewise force profiles with known impulse and takeoff velocity.
- Controlled timestamp jitter and missing sample.
- Axis sign reversal and unit errors.
- Clipping/saturation.
- Multiple countermovements.
- False flight gaps/noise spikes.
- Nonuniform sampling.
- Dual-plate desynchronization.
- Vendor-filtered versus raw signals.
- Boundary events exactly at threshold.

Synthetic tests prove formulas and invariants but do not replace human/device validation.

### 19.3 Agreement and reliability tests

Correlation is insufficient. Qualification reports bias, limits of agreement, interval coverage, repeatability/reproducibility, CV/typical error/SEM where design supports them, sensitivity to processing definitions, and practical decision impact. CMJ system comparability requires device/configuration-specific evidence [W31].

### 19.4 Release gate

A scientific release requires:

- passing automated tests and frozen benchmark digest;
- independent code/method review;
- scope and limitation manifest;
- evidence-tier assignment;
- reproducible build and SBOM;
- signed release attestation;
- registry publication;
- rollback/deprecation plan.

![Scientific release factory](diagrams/release_factory.png){width=95%}

## 20. CI/CD and supply-chain design

### 20.1 Pipeline

1. Format/lint/type check.
2. Unit/property/schema tests.
3. Build generated contracts and fail on diff.
4. Scientific golden/metamorphic/differential tests.
5. Integration and security tests.
6. Build isolated OCI images and packages.
7. Produce SPDX or CycloneDX SBOM.
8. Produce SLSA provenance and in-toto/DSSE attestations.
9. Sign images, packages, manifests, and release bundles with Cosign.
10. Deploy to ephemeral test environment.
11. Run end-to-end and evidence replay tests.
12. Promote by digest through staging to production.

Build systems, not individual developer machines, produce release provenance, consistent with SLSA guidance [W10, S12]. Releases are frequent and reversible rather than large high-risk deployments [S12].

### 20.2 Branch and release policy

- Trunk-based or short-lived branches.
- Protected main and required review.
- Conventional commit/release metadata only where useful; scientific semantic change gets explicit changelog.
- Dependency updates through automated PRs plus scientific regression suite.
- Feature flags may hide UI features but cannot alter released scientific semantics invisibly.
- Database migrations use expand/migrate/contract and are rehearsed.

## 21. Deployment topology

### Development

Docker Compose or equivalent local stack: Postgres, S3-compatible local object store, Temporal dev server, OTel collector, control API, web, and workers. Scientific kernel tests run without containers.

### Staging

Production-like managed services, synthetic/deidentified data, real signing verification, full security and replay tests.

### Production MVP

- Managed container service, not Kubernetes by default.
- Managed PostgreSQL and object storage.
- Managed Temporal or qualified self-hosted deployment.
- Edge/WAF and identity provider.
- Separate worker pools for adapter, deterministic processor, inference, and evidence.
- OTel collector to selected observability backend.
- Environment separation by account/project, not only namespace.

Kubernetes becomes eligible only when measured requirements such as multi-region scheduling, specialized autoscaling, platform-team operation, or service count justify its cost.

## 22. Data and schema evolution

- Additive optional fields require declared defaults/absence semantics.
- Removing, renaming, unit-changing, or semantic reinterpretation is breaking.
- Canonical acquisition versions coexist; adapters target exact versions.
- Migrations create new canonical artifacts rather than rewriting the source.
- Scientific results never migrate in place; a reprocess creates a new run and explicit comparison.
- Registry resolution can pin exact digest or accept compatible version ranges under policy.

## 23. Operational runbooks

Required before pilot:

- Unsupported/schema-drift import.
- Conflicting sample-rate/filter metadata.
- Deterministic replay mismatch.
- Statistical diagnostic failure.
- Evidence-signature verification failure.
- Practitioner override dispute.
- Agent prohibited-output incident.
- Tenant-isolation/security incident.
- Object-store corruption/restore.
- Scientific-release deprecation and emergency block.

Every incident links affected evidence manifests and determines whether practitioner notification or reprocessing is required.

## 24. Implementation sequence

### Increment 1 - Schemas and fixture corpus

Deliver source artifact, mapping, acquisition, configuration, protocol, event, quality, metric, and evidence schemas; create two mocked adapter fixtures and verifier skeleton.

### Increment 2 - Canonicalization and configuration

Implement one real export adapter, canonical Parquet package, configuration resolver, fail-closed policy, and mapping-review CLI.

### Increment 3 - Deterministic CMJ kernel

Implement quiet standing, events, integration primitives, one primary metric, descriptive metrics, calculation trace, and independent oracle tests.

### Increment 4 - Evidence authority

Implement registry, run manifest, W3C PROV relations, RO-Crate export, digests, signing, verifier replay, and lifecycle policy.

### Increment 5 - Statistical baseline

Implement reference epochs and a simple calibrated model; then benchmark PyMC and Stan implementations before selecting production inference runtime.

### Increment 6 - Practitioner web workflow

Implement upload, mapping review, trial trace, decision card, reference approval, evidence export, and audit.

### Increment 7 - Durable workflow and Eve spike

Introduce Temporal for approval/retry workflows and qualify Eve against exact tool contracts. Do not introduce either earlier solely for architectural fashion.

### Increment 8 - Validation and pilot

Freeze benchmark, run retrospective evaluation, prospective pilot, external review, and commercial gates.

## 25. Required architecture spikes

| Spike | Question | Pass condition |
| --- | --- | --- |
| SPK-01 Native exports | Can two vendor surfaces be mapped without proprietary hidden calculations? | All required vertical channels and source semantics are reconstructable or explicitly unknown. |
| SPK-02 Parquet schema | Does canonical storage round-trip all timing/channel semantics? | No semantic loss; deterministic cross-language reads. |
| SPK-03 C3D | Can ezc3d or alternative preserve platform geometry/type/calibration correctly? | Conformance corpus and independent inspection pass. |
| SPK-04 Numeric reproducibility | How stable are results across OS/BLAS/CPU? | Prespecified deterministic/tolerance bounds pass. |
| SPK-05 PyMC vs Stan vs analytic | Which runtime is calibrated, diagnosable, maintainable, and fast enough? | Known-truth and real-corpus benchmark accepted. |
| SPK-06 Temporal | Does durable workflow complexity justify adoption? | Restart, retry, idempotency, approval wait, and export pass with acceptable ops cost. |
| SPK-07 Eve | Can the agent remain bounded and portable? | Typed tools, restart, approvals, trace, eval, data minimization, and fallback pass. |
| SPK-08 Evidence signing | Can public and private deployment profiles verify bundles long term? | Offline/online verification and key rotation pass. |
| SPK-09 OpenAPI 3.2 | Do generators and gateways support required features? | Generated TS/Python clients and contract tests pass; otherwise use 3.1 projection. |

## 26. Rejected implementation shortcuts

- One TypeScript service calculating force-plate metrics for convenience.
- Pandas DataFrames as the canonical scientific schema.
- Storing all samples as relational rows.
- An ORM model as the domain contract authority.
- Vendor metric values as the independent result.
- Generic “raw_data: any” payloads.
- LLM-generated formulas or thresholds.
- Unversioned notebook calculations in production.
- A Kafka/event-sourcing platform before scale evidence.
- Kubernetes before operational need.
- A proprietary evidence format with no independent verifier.
- A single signing key for build, science, runtime, and practitioner decisions.

## 27. Definition of technical completion for v0.1

The v0.1 technical foundation is complete only when one real native export can be imported, canonically represented, configuration-qualified, processed through a released small metric pack, replayed independently, assembled into a signed portable evidence crate, reviewed by an authenticated practitioner, and verified without the web application or Eve. No performance interpretation beyond the accepted scientific evidence tier is permitted.

## References and source register

References marked “uploaded” were supplied in the project source set. Web sources were checked on 2026-08-03. Vendor and framework pages establish capabilities and specifications, not independent scientific efficacy.

- **[S01] SportsAgentsLab Master Opportunity, Product Portfolio, and Project Handoff.** SportsAgentsLab internal handoff, research freeze 2026-08-01. Strategic source of truth for product sequence, autonomy, evidence tiers, and human authority. uploaded source
- **[S02] Vladimir M. Zatsiorsky, Kinetics of Human Motion.** Human Kinetics. Newtonian mechanics, external forces, vector analysis, and physical-model discipline. uploaded book
- **[S03] Vladimir M. Zatsiorsky, Kinematics of Human Motion.** Human Kinetics. Coordinate systems, motion representation, velocity, acceleration, and kinematic-chain terminology. uploaded book
- **[S04] Paavo V. Komi (ed.), Strength and Power in Sport, 2nd ed..** IOC Medical Commission / Blackwell Science. SI units and definitions of force, work, power, torque, and stretch-shortening-cycle performance. uploaded book
- **[S05] Zatsiorsky, Kraemer, and Fry, Science and Practice of Strength Training, 3rd ed..** Human Kinetics, 2021. Task specificity, monitoring, testing, and the limits of recipe-style interpretation. uploaded book
- **[S06] Eugene N. Bruce, Biomedical Signal Processing and Signal Modeling.** Wiley, 2001. Signal-model assumptions, desired signal versus noise, measurement-device effects, filtering, and model adequacy. uploaded book
- **[S07] Willis J. Tompkins (ed.), Biomedical Digital Signal Processing.** Prentice Hall, 1993. Sampling, conversion, filtering, signal averaging, real-time DSP, and finite-precision considerations. uploaded book
- **[S08] Tulay Adali and Simon Haykin (eds.), Adaptive Signal Processing.** Wiley, 2010. Robustness under non-Gaussianity, nonstationarity, nonlinearity, and outliers. uploaded book
- **[S09] Joseph D. Bronzino and Donald R. Peterson (eds.), Biomedical Engineering Fundamentals, 4th ed..** CRC Press, 2015. Interdisciplinary engineering, instrumentation, hazards, efficacy, and computational modeling. uploaded book
- **[S10] Jake VanderPlas, Python Data Science Handbook.** O’Reilly, 2017. Python scientific stack and array-oriented data processing. uploaded book
- **[S11] Dan Vanderkam, Effective TypeScript, 2nd ed..** O’Reilly, 2024. Valid-state type design, readonly contracts, schema-derived types, exhaustive checking, and strictness. uploaded book
- **[S12] Durkin, Minick, and Gaikwad, AI-Native Software Delivery.** O’Reilly, 2025. Platform-as-product, progressive delivery, CI/CD governance, SLSA, SBOMs, and observability. uploaded book
- **[W01] Vercel Eve announcement and repository.** Durable sessions, approval gates, typed tools, sandboxing, subagents, traces, evaluations, and beta status. https://vercel.com/blog/introducing-eve ; https://github.com/vercel/eve
- **[W02] ISO/IEC/IEEE 42010:2022.** Requirements for architecture descriptions, concerns, viewpoints, and rationale. https://www.iso.org/standard/74393.html
- **[W03] ISO/IEC 25010:2023.** Product quality model for specifying and evaluating software quality. https://www.iso.org/standard/78176.html
- **[W04] ISO/IEC 25002:2024 and ISO/IEC 25040:2024.** Quality-model usage and evaluation frameworks. https://www.iso.org/standard/78175.html ; https://www.iso.org/committee/45086/x/catalogue/
- **[W05] NIST SP 800-218 SSDF 1.1.** Final secure software development framework. https://csrc.nist.gov/pubs/sp/800/218/final
- **[W06] NIST SP 800-218 Rev. 1 / SSDF 1.2.** Initial public draft; monitored but not treated as final authority. https://csrc.nist.gov/pubs/sp/800/218/r1/ipd
- **[W07] NIST SP 800-218A.** Secure software development practices for generative AI and dual-use foundation models. https://csrc.nist.gov/pubs/sp/800/218/a/final
- **[W08] OWASP ASVS 5.0.0.** Application-security verification baseline. https://owasp.org/www-project-application-security-verification-standard/
- **[W09] OWASP LLM Verification Standard 2.0.** 2026 verification requirements for LLM-enabled systems. https://owasp.org/www-project-llm-verification-standard/LLMSVS-v2.0-en.html
- **[W10] SLSA specification 1.2.** Software artifact provenance and build integrity. https://slsa.dev/spec/v1.2/
- **[W11] Sigstore Cosign documentation.** Keyless artifact and blob signing, certificates, transparency log, and verification bundles. https://docs.sigstore.dev/quickstart/quickstart-cosign/
- **[W12] W3C PROV-O.** Domain-independent provenance ontology based on Entity, Activity, and Agent. https://www.w3.org/TR/prov-o/
- **[W13] RO-Crate 1.2 and Workflow Run RO-Crate.** Portable file-oriented research-object and computational-run packaging. https://www.researchobject.org/ro-crate/specification/1.2/ ; https://www.researchobject.org/workflow-run-crate/
- **[W14] JCGM 100:2008 GUM and JCGM GUM-1:2023.** Expression and evaluation of measurement uncertainty. https://www.bipm.org/en/committees/jc/jcgm/publications
- **[W15] JCGM 200:2012 VIM.** International vocabulary of metrology. https://www.bipm.org/en/committees/jc/jcgm/publications
- **[W16] C3D force-platform specification.** Force-platform type, channel, geometry, origin, and calibration-matrix semantics; Type 4 is not “4D”. https://www.c3d.org/HTML/Documents/forceplatformtype.htm
- **[W17] UCUM.** Unambiguous machine-readable unit representation. https://ucum.org/ucum
- **[W18] JSON Schema 2020-12.** Canonical schema and validation vocabulary. https://json-schema.org/draft/2020-12
- **[W19] OpenAPI 3.2.0.** Current API description standard; tooling compatibility must be qualified. https://spec.openapis.org/oas/v3.2.0.html
- **[W20] Apache Arrow and Parquet.** Cross-language columnar memory model and durable columnar storage. https://arrow.apache.org/docs/format/Columnar.html ; https://parquet.apache.org/docs/
- **[W21] PostgreSQL 18.4.** Current PostgreSQL documentation and supported release. https://www.postgresql.org/docs/current/
- **[W22] Python 3.14.6 and Python 3.13.14.** Current stable and conservative scientific-runtime qualification targets. https://www.python.org/downloads/
- **[W23] Node.js releases.** Production applications should use Active or Maintenance LTS; Node 24 is the selected baseline. https://nodejs.org/en/about/previous-releases
- **[W24] TypeScript 6.0 and 5.9 documentation.** 6.0 is a transition release; 5.9 remains the initial compatibility baseline pending dependency qualification. https://www.typescriptlang.org/docs/handbook/release-notes/typescript-6-0.html
- **[W25] FastAPI and Pydantic.** Typed Python API and runtime-validation candidates. https://fastapi.tiangolo.com/ ; https://docs.pydantic.dev/latest/
- **[W26] PyMC 6.2 documentation.** Primary candidate for hierarchical Bayesian model development and production inference. https://docs.pymc.io/
- **[W27] Stan 2.39 / CmdStan.** Independent statistical oracle and reference implementation candidate. https://mc-stan.org/docs/reference-manual/ ; https://mc-stan.org/tools/
- **[W28] Temporal documentation.** Durable workflow execution, retries, timers, and human wait states. https://docs.temporal.io/
- **[W29] OpenTelemetry documentation.** Vendor-neutral traces, metrics, logs, OTLP, and collector. https://opentelemetry.io/docs/
- **[W30] Countermovement jump metric reliability review.** Metric dimensionality and reliability vary; supports a deliberately small qualified pack. https://pmc.ncbi.nlm.nih.gov/articles/PMC9865236/
- **[W31] Merrigan et al., CMJ force-time reliability and comparability across force-plate systems.** Supports device/configuration-specific agreement qualification. https://pubmed.ncbi.nlm.nih.gov/37815253/
- **[W32] Hori et al., reliability and sampling frequency.** Sampling frequency affects some derived outcomes and must be a contract dimension. https://ro.ecu.edu.au/cgi/viewcontent.cgi?article=1506&context=ecuworks
- **[W33] Meylan et al., CMJ movement-onset thresholds.** Event definitions materially affect results and must be frozen and tested. https://pubmed.ncbi.nlm.nih.gov/20664368/
- **[W34] Reliability of vertical-jump force-time metrics in collegiate athletes.** Recent evidence that reliability is metric-specific, not guaranteed by hardware capability. https://pmc.ncbi.nlm.nih.gov/articles/PMC12733763/
