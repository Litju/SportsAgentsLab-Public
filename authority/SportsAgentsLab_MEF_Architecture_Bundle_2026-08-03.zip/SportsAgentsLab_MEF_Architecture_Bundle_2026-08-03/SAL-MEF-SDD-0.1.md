---
title: "System Design Description (SDD)"
subtitle: "SportsAgentsLab Measurement Evidence Factory"
author: "SportsAgentsLab"
date: "2026-08-03"
lang: en-US
---

# System Design Description (SDD)

**Document ID:** `SAL-MEF-SDD-0.1`  
**Version:** `0.1.0`  
**Status:** `CURATED_BASELINE_FOR_OWNER_REVIEW`  
**Research freeze:** 2026-08-03  
**Implementation authority:** Not granted by this document  
**Purpose:** Define the product, scientific, data, authority, evidence, user-workflow, quality, validation, and acceptance contract for the Measurement Evidence Factory.

> **Normative language.** “MUST”, “MUST NOT”, “SHOULD”, “SHOULD NOT”, and “MAY” are used as requirements terms. A requirement is not scientifically qualified merely because it appears here. Scientific claims advance only through the defined evidence gates.

> **Safety boundary.** The system does not diagnose injury, infer unsupported training causality, clear an athlete, prescribe medical action, or conceal uncertainty behind generic readiness labels. Qualified practitioners retain final interpretation.


## 1. Executive decision

SportsAgentsLab will treat the Measurement Evidence Factory (MEF) as an independent scientific and evidentiary system beneath any conversational or agentic interface. The first vertical slice is a bilateral, unloaded, hands-on-hips countermovement jump processed from force-plate data. The architecture is vendor-agnostic at the product boundary but configuration-, protocol-, sample-rate-, preprocessing-, population-, and metric-pack-specific at the scientific boundary.

The MEF consists of three separable systems:

1. **Qualification factory** - develops, verifies, validates, reviews, releases, deprecates, and retires scientific objects.
2. **Execution factory** - applies only eligible released objects to a specific assessment.
3. **Evidence and authority plane** - verifies scope and integrity, preserves human decisions, and controls what claims can be made.

Eve is a mandatory runtime candidate for the Measurement Review Agent, but it remains outside the scientific substrate. The LLM coordinates and explains; deterministic processors calculate; statistical components estimate uncertainty; the evidence authority verifies eligibility; the practitioner interprets and decides. This follows the master handoff’s requirement that the LLM not be the scientific substrate and that evidence precede autonomy [S01].

![System context](diagrams/system_context.png){width=95%}

## 2. Architecture-description method

This SDD is organized around stakeholder concerns and viewpoints consistent with ISO/IEC/IEEE 42010:2022 [W02]. Product-quality requirements use the ISO/IEC 25010:2023 vocabulary where useful [W03]. Scientific content is constrained by metrological vocabulary and uncertainty principles from VIM and GUM [W14, W15]. Security and software-delivery controls are anchored in final NIST SSDF 1.1 and OWASP ASVS 5.0; draft SSDF 1.2 is monitored but is not normative [W05, W06, W08].

## 3. Mission and product job

> Given an exact native source artifact, acquisition configuration, sample-rate contract, assessment protocol, processor release, metric pack, supported population, reference epoch, and inference pack, determine what was measured, whether it is comparable, what changed, how uncertain the estimate is, what practical threshold applies, and what evidence supports the statement - while preserving practitioner authority.

### 3.1 Primary user

The first user is a lead strength-and-conditioning coach or applied sport scientist managing approximately 20-150 athletes in a private performance facility, academy, university/regional program, or semi-professional team. The user already owns force plates, regularly exports data, and currently reconciles protocol quality, spreadsheets, vendor dashboards, and individual baselines manually.

### 3.2 Recurring decision

After a repeated assessment session, the practitioner must decide:

- whether the source and protocol are valid;
- whether each trial should be accepted, excluded, or repeated;
- whether the session is comparable with the approved reference;
- whether the apparent change is distinguishable from expected measurement variation;
- whether an approved practical threshold is exceeded;
- whether the record should be accepted, annotated, overridden, retested, rejected, or placed in a new non-comparable regime.

### 3.3 Supported first assessment

The initial scientific contract is `CMJ.BILATERAL.UNLOADED.HANDS_ON_HIPS.v1`. Target validation population: trained adult field- and court-sport athletes aged 18-35 who are organizationally cleared to jump. Initial signal scope is total vertical ground-reaction force from a qualified single-total or dual-independent platform configuration. Three-axis and six-component source channels may be preserved, but they do not activate additional metrics until separately qualified.

## 4. Product principles and invariants

1. **Vendor-agnostic is not configuration-agnostic.** Vendor identity is an ingestion concern; physical channels, coordinates, timing, calibration, and preprocessing define scientific eligibility.
2. **The native artifact is evidence.** It is retained unchanged and remains the root of provenance.
3. **Unknown remains unknown.** Missing sample rate, filters, axes, synchronization, or calibration cannot be guessed from marketing material.
4. **A metric is not eligible merely because it is calculable.** Calculation, reliability, longitudinal inference, and practical-threshold eligibility are separate states.
5. **Signal processing implements a declared model.** Bruce emphasizes that desired signal versus noise must derive from knowledge of the source and measurement process; the processor cannot create that distinction by convenience [S06].
6. **No silent signal transformations.** Sampling, filtering, interpolation, integration, drift correction, and event thresholds are explicit versioned operations. Anti-alias and sampling constraints are part of the acquisition contract [S06, S07].
7. **Human-observed protocol facts stay human-observed.** The force trace cannot prove every execution condition.
8. **Evidence is stronger than narrative.** The explanation references verified typed outputs; it is not the evidence itself.
9. **No generic readiness.** The system reports measurement and change states only.
10. **No unsupported causality.** Temporal sequence or association does not establish a training effect.

## 5. Scope

### 5.1 MVP in scope

- Native CSV or equivalent raw export from two qualified vendor/export surfaces.
- Optional standards-compliant C3D ingestion after the C3D qualification spike.
- Single-total and dual-independent vertical-force configurations.
- Explicit qualified sample rates, initially expected to include 1,000 Hz but frozen only after corpus inspection and testing.
- One exact CMJ protocol.
- A small closed vertical-core metric pack.
- One primary inferential metric: impulse-momentum jump height.
- Trial trace, event, quality, and exclusion review.
- Fixed practitioner-approved reference epochs.
- Measurement uncertainty and SESOI-aware change inference.
- Evidence bundle, replay manifest, practitioner decision, and export.
- Agent-assisted missing-data resolution and explanation behind a framework-neutral port.

### 5.2 Explicitly out of scope

- Injury diagnosis, risk prediction, return-to-play clearance, or medical advice.
- Training prescription or automatic load changes.
- Generic readiness, fatigue, recovery, or neuromuscular-status scores.
- Arm-swing, loaded, single-leg, repeated, rebound, or drop-jump protocols.
- Inter-limb asymmetry classification in the first release.
- Contact mats, phone-only estimates, optical systems, or files lacking qualified force channels.
- Arbitrary user-created formulas or metric menus.
- Cross-device pooling without accepted agreement evidence.
- Vendor APIs before export-native workflow value is proved.
- Marketplace or broad SportsAgentsLab platform work.

## 6. Scientific contract

### 6.1 Permitted claim

Under the declared source, protocol, acquisition, processing, metric, population, reference, and uncertainty contracts, the current session is valid or invalid, comparable or non-comparable, and its estimated difference is compatible with expected measurement variation, distinguishable, practically important under a registered SESOI, or unresolved.

### 6.2 Interpretation layers

1. **Measurement eligibility** - deterministic data and protocol decision.
2. **Statistical distinguishability** - uncertainty-aware estimate relative to approved comparison data.
3. **Practical importance** - probability relative to a registered SESOI.

These layers must never be collapsed. GUM addresses uncertainty of measurement, while a SESOI expresses decision value; MDC/SDC is not automatically a meaningful threshold [W14].

### 6.3 Biomechanical quantities and units

Stored quantities use SI units and explicit dimensions. Force is stored in newtons, mass in kilograms, time in seconds, velocity in metres per second, displacement in metres, impulse in newton-seconds, work in joules, and power in watts. This follows the sports-mechanics terminology in Komi and Zatsiorsky [S02, S04]. Display conversions, if later allowed, are presentation-only.

### 6.4 Primary metric strategy

The first pack retains one primary inferential metric - impulse-momentum jump height - and a small descriptive context set such as contraction time, takeoff velocity, net vertical impulse, and countermovement displacement. RFD, arbitrary early-force values, asymmetry classifications, peak-power scores, and composite readiness indices remain excluded until metric-specific evidence supports them. Contemporary CMJ literature shows that metric reliability and comparability differ materially, justifying a small pack [W30, W31, W34].

### 6.5 Event and transformation governance

Movement onset, takeoff, landing, phase transitions, integration initial conditions, gravity constant, quiet-standing window, force threshold, filtering, and drift logic are processor-contract fields. Movement-onset thresholds can materially change CMJ outputs [W33]. No hard-coded threshold becomes authoritative before benchmark and sensitivity gates pass.

## 7. Acquisition and vendor model

### 7.1 Exact configuration identity

A configuration contract includes:

- platform count and relationship;
- measured force and moment channels per platform;
- raw, calibrated, vendor-scaled, or vendor-derived signal state;
- coordinate frame, handedness, axis definitions, and signs;
- geometry, origin, corners, and calibration matrix where relevant;
- nominal and observed sample timing;
- synchronization and timestamp source;
- filter, smoothing, resampling, and export preprocessing state;
- zeroing/calibration metadata;
- eligible protocols and metric packs.

The system does not use “2D/3D/4D” as canonical identities. In C3D, Force Platform Type 4 denotes a platform supplied with a full calibration matrix; it does not mean four-dimensional measurement [W16].

### 7.2 Configuration resolution states

| State | Meaning | Permitted progression |
| --- | --- | --- |
| RESOLVED_QUALIFIED | All required semantics are known and an eligible release exists. | Qualified processing. |
| RESOLVED_UNQUALIFIED | Semantics are known but no released qualification covers the combination. | Import and descriptive inventory only. |
| PARTIALLY_RESOLVED | Required fields remain unknown. | Human resolution workflow; no qualified metrics. |
| CONFLICTING_METADATA | File, device record, or user metadata conflict. | Quarantine and adjudication. |
| UNRESOLVED | Source cannot be safely interpreted. | Reject qualified processing. |

## 8. Domain model

The domain is modeled around immutable entities, explicit activities, authority-bearing agents, and state transitions.

### 8.1 Core entities

| Aggregate | Key objects | Invariant |
| --- | --- | --- |
| Source | SourceArtifact, SourceSchemaObservation, ImportAttempt, ColumnMapping | Original bytes and digest never change. |
| Acquisition | CanonicalAcquisition, Channel, Timebase, CoordinateFrame, CalibrationReference | Every sample has explicit quantity, unit, source, and timing semantics. |
| Scientific contract | ConfigurationContract, ProtocolContract, ProcessorRelease, MetricDefinition, MetricPack, ReliabilityProfile, InferencePack | Released versions are immutable and content-addressed. |
| Assessment | Athlete, AssessmentSession, Attempt, Trial, EventRecord, QualityRecord, MetricObservation | Invalid attempts are annotated, not deleted. |
| Reference and inference | ReferenceEpoch, BaselineState, SessionEstimate, ChangeEstimate, SESOIRegistration | Reference selection and thresholds require explicit authority. |
| Evidence | EvidenceManifest, EvidenceArtifact, Attestation, VerificationResult | Every claim links to exact artifacts and scope. |
| Authority | Actor, Role, Approval, Override, Decision | No consequential decision is anonymous or silent. |

### 8.2 Ubiquitous language

- **Source artifact:** exact received vendor file or payload.
- **Canonical acquisition:** normalized but provenance-preserving representation of acquisition channels and metadata.
- **Configuration contract:** physical and digital acquisition semantics.
- **Protocol contract:** athlete task and collection procedure.
- **Processor release:** exact deterministic code and dependency build.
- **Metric definition:** one quantity, formula, dependencies, units, and scope.
- **Metric pack:** closed eligible set of metrics plus aggregation and interpretation rules.
- **Reliability profile:** measurement properties for a metric under a configuration, protocol, population, and design.
- **Inference pack:** exact estimand, model, priors, diagnostics, reference selection, and outputs.
- **Evidence authority:** policy-controlled verifier; it verifies eligibility and integrity, not scientific truth by cryptography.
- **Practitioner decision:** final human disposition recorded against verified evidence.

## 9. Functional requirements

| ID | Capability | Requirement | Priority |
| --- | --- | --- | --- |
| FR-001 | Artifact intake | The system MUST accept supported native vendor exports without requiring the vendor to adopt a SportsAgentsLab file format. | P0 |
| FR-002 | Immutable source preservation | The exact received artifact MUST be stored unchanged with a cryptographic digest before parsing. | P0 |
| FR-003 | Source classification | Every field MUST be classified as raw sensor, vendor-scaled sensor, vendor-derived signal, vendor-derived event, vendor-derived metric, user metadata, or unknown. | P0 |
| FR-004 | Adapter resolution | The system MUST resolve vendor, export surface, observed schema, and adapter version; vendor name alone is insufficient. | P0 |
| FR-005 | Schema drift detection | An unrecognized or changed source schema MUST fail closed or enter explicit review; it MUST NOT be silently coerced. | P0 |
| FR-006 | Canonical acquisition | A successful import MUST create a canonical acquisition with channels, units, axes, timestamps, sample rate, provenance, and unresolved fields. | P0 |
| FR-007 | Configuration resolution | The system MUST resolve actual plate count, independent/summed channels, measured quantities, coordinate convention, sample rate, synchronization, calibration, and prior preprocessing. | P0 |
| FR-008 | Marketing-label isolation | Labels such as 2D, 3D, or 4D MAY be retained as source metadata but MUST NOT determine scientific eligibility. | P0 |
| FR-009 | Sampling contract | Nominal and observed sampling characteristics MUST be part of the configuration contract. | P0 |
| FR-010 | No silent resampling | The system MUST NOT upsample, downsample, interpolate, or reconstruct missing samples without an explicitly qualified transformation contract. | P0 |
| FR-011 | Protocol contract | Every trial MUST reference an exact assessment protocol version and declared execution conditions. | P0 |
| FR-012 | Trial retention | All attempts, including invalid or excluded attempts, MUST be retained with reasons and authority. | P0 |
| FR-013 | Trial quality | The processor MUST emit deterministic structural, signal, event, and protocol checks before metrics become eligible. | P0 |
| FR-014 | Human-observed conditions | Conditions not inferable from force data, such as hands remaining on hips, MUST remain human-confirmed; the system MUST NOT fabricate them. | P0 |
| FR-015 | Closed metric pack | Metrics MUST be activated only through a predetermined, immutable, versioned metric pack. | P0 |
| FR-016 | Configuration eligibility | A metric MUST execute only when its configuration, protocol, sampling, preprocessing, population, and code-build requirements are satisfied. | P0 |
| FR-017 | Metric status | Each metric MUST declare calculation, descriptive, reliability, longitudinal-inference, and practical-threshold eligibility separately. | P0 |
| FR-018 | Deterministic trace | Each metric result MUST link to exact inputs, events, formulas, code digest, dependencies, and intermediate values needed for replay. | P0 |
| FR-019 | Session aggregation | The session estimator, valid-trial count, trial-order rule, and missing-trial policy MUST be declared by the metric pack. | P0 |
| FR-020 | Reference epoch | The inference service MUST use an explicitly approved reference epoch; it MUST NOT silently replace a fixed baseline with a rolling baseline. | P0 |
| FR-021 | Comparability regime | Material changes in protocol, configuration, sample rate, firmware, filtering, processor, or metric pack MUST create a new comparability regime unless a bridge study is accepted. | P0 |
| FR-022 | Measurement uncertainty | Inference MUST separate the estimate, measurement uncertainty, and practical importance. | P0 |
| FR-023 | Sparse-baseline handling | The system MUST declare baseline maturity and restrict claims when athlete-specific evidence is sparse. | P0 |
| FR-024 | SESOI governance | A smallest effect size of interest MUST be metric-, population-, decision-, and version-specific and approved by a qualified human. | P0 |
| FR-025 | No generic meaningfulness | Without a registered SESOI, the system MAY report direction and distinguishability but MUST NOT call a change practically meaningful. | P0 |
| FR-026 | Evidence bundle | Every completed run MUST produce a portable evidence bundle containing source, canonical data, contracts, processing, inference, diagnostics, authority, and checksums. | P0 |
| FR-027 | Evidence verification | An evidence authority MUST verify integrity and scope before a result can be marked processing-eligible, inference-eligible, or practitioner-reviewed. | P0 |
| FR-028 | Separate authorities | Build, scientific qualification, runtime, practitioner, and organization authority MUST be distinguishable. | P0 |
| FR-029 | Practitioner decision | A practitioner MUST be able to accept, override, request retest, annotate, reject, or establish a new non-comparable reference context. | P0 |
| FR-030 | Override attribution | Every override MUST store actor, time, reason, prior value, new value, and affected evidence. | P0 |
| FR-031 | Agent boundedness | The agent MAY coordinate tools, ask for missing information, explain verified outputs, and recommend review; it MUST NOT calculate metrics or alter scientific contracts. | P0 |
| FR-032 | Agent portability | Agent orchestration MUST depend on a framework-neutral runtime port; Eve is an adapter candidate, not scientific authority. | P1 |
| FR-033 | Traceability | Every evidence-card statement MUST be traceable to a typed result, policy rule, or cited limitation. | P0 |
| FR-034 | Result language | Output language MUST distinguish invalid, non-comparable, insufficient, distinguishable, practically important, and uncertain states. | P0 |
| FR-035 | Forbidden labels | The system MUST NOT emit “ready”, “not ready”, “fatigued”, “injured”, “recovered”, or equivalent generic state labels. | P0 |
| FR-036 | Forbidden causality | The system MUST NOT attribute a change to training, illness, competition, sleep, or another cause unless a separate qualified causal design supports that claim. | P0 |
| FR-037 | Registry lifecycle | Scientific objects MUST support draft, verified, released, deprecated, and retired lifecycle states without mutable released versions. | P0 |
| FR-038 | Evidence tiers | Public and internal claims MUST declare the applicable E0-E5 evidence tier and supported scope. | P0 |
| FR-039 | Export | Authorized users MUST be able to export human-readable and machine-readable evidence without dependence on the agent runtime. | P1 |
| FR-040 | Independent replay | A verifier MUST be able to replay deterministic results from released artifacts and the evidence bundle. | P0 |

## 10. Quality and non-functional requirements

| ID | Characteristic | Requirement | Criticality |
| --- | --- | --- | --- |
| NFR-001 | Scientific reproducibility | Identical deterministic inputs and build MUST produce identical outputs; stochastic inference MUST be replayable from data, code, configuration, seeds, and retained draws/summaries. | Critical |
| NFR-002 | Fail-closed behavior | Unknown units, axes, schema, sample rate, filter state, or configuration MUST block qualified processing. | Critical |
| NFR-003 | Auditability | All material state changes MUST be append-only auditable and attributable. | Critical |
| NFR-004 | Data integrity | Artifacts MUST use collision-resistant digests; manifests MUST bind all referenced content. | Critical |
| NFR-005 | Tenant isolation | Organization data MUST be logically isolated and tested through database and application controls. | Critical |
| NFR-006 | Least privilege | Services, users, and agents MUST receive minimum scoped credentials and actions. | Critical |
| NFR-007 | Privacy minimization | Raw athlete data MUST not be placed in LLM context unless explicitly necessary, authorized, minimized, and logged. | Critical |
| NFR-008 | Availability | MVP monthly service availability target is 99.5%, excluding declared maintenance; scientific evidence remains exportable during agent outage. | High |
| NFR-009 | Durability | Accepted source artifacts and evidence manifests MUST meet eleven-nines object durability through managed storage or equivalent controls. | High |
| NFR-010 | Performance | A three-trial CMJ file under 10 MB SHOULD reach deterministic review within 10 s at p95 under normal load. | High |
| NFR-011 | Inference latency | A cached or analytic inference SHOULD complete within 10 s p95; full Bayesian refits MAY be asynchronous with explicit status. | Medium |
| NFR-012 | Scalability | The initial architecture SHOULD support 100 organizations, 20,000 athletes, and 5 million trials without redesign of domain contracts. | Medium |
| NFR-013 | Portability | Scientific packages MUST run through CLI and library interfaces without the web application or Eve. | Critical |
| NFR-014 | Interoperability | Canonical exports SHOULD support JSON/Parquet and an RO-Crate profile; C3D input SHOULD be supported after qualification. | High |
| NFR-015 | Maintainability | Module boundaries, generated contracts, strict typing, small scientific kernels, and architecture tests MUST prevent cyclic or hidden coupling. | High |
| NFR-016 | Testability | Every released scientific object MUST have unit, property, golden-corpus, and adversarial tests appropriate to its scope. | Critical |
| NFR-017 | Observability | Services MUST emit trace, metric, and structured-log signals with evidence/run correlation identifiers. | High |
| NFR-018 | Security baseline | The product MUST map controls to NIST SSDF 1.1 and OWASP ASVS 5.0; AI surfaces SHOULD additionally map to OWASP LLMSVS 2.0. | Critical |
| NFR-019 | Supply-chain integrity | Release artifacts MUST include SBOM, provenance attestation, digest, signature, and verification policy. | Critical |
| NFR-020 | Backward compatibility | Schemas and APIs MUST use explicit compatibility rules; silent semantic reinterpretation is forbidden. | Critical |
| NFR-021 | Accessibility | Practitioner web surfaces SHOULD meet WCAG 2.2 AA for core workflows. | High |
| NFR-022 | Internationalization | Units remain canonical SI; display localization MUST NOT change stored quantities or semantics. | Medium |
| NFR-023 | Recoverability | Target RPO is 15 min for operational state and zero for immutable accepted source/evidence objects; target RTO is 4 h for MVP. | High |
| NFR-024 | Cost control | Each run MUST expose compute/storage cost dimensions; expensive inference cannot be triggered by unbounded agent loops. | High |

## 11. End-to-end workflows

### 11.1 New export onboarding

1. Practitioner uploads a native export.
2. System hashes and preserves the artifact before parsing.
3. Adapter identifies the source surface and observed schema.
4. Canonicalizer maps source columns, units, axes, timebase, and plate identity.
5. Configuration resolver evaluates qualification eligibility.
6. Missing or conflicting metadata becomes a human task.
7. A qualified mapping can be approved for a specific adapter/schema combination; approval does not approve metrics for every device from that vendor.

### 11.2 Assessment execution

![Scientific execution pipeline](diagrams/scientific_pipeline.png){width=100%}

The execution factory is idempotent. Each step consumes immutable references and emits immutable artifacts plus state transitions. A retry cannot duplicate accepted results because the run identity includes source digest, contract digests, and processor release.

### 11.3 Practitioner review

The principal screen is a decision review, not a generic dashboard. It shows source identity, comparability, trace and event overlays, trial inclusion, session estimate, reference epoch, measurement uncertainty, SESOI probabilities when authorized, limitations, and a decision action. The user can accept, override, retest, reject, or establish a new context. Every action creates an auditable decision record.

### 11.4 Agent-assisted review

The agent may ask for missing metadata, describe failed gates, call approved tools, summarize the evidence card, and explain uncertainty. It may not execute arbitrary Python, request arbitrary metrics, modify thresholds, select a new baseline, define a SESOI, or sign a scientific release. Eve’s durable sessions and approval gates are a strong fit, but its beta status requires a bounded qualification and a portability adapter [W01].

## 12. State models

### 12.1 Evidence state

![Evidence state machine](diagrams/evidence_state.png){width=95%}

State advancement is monotonic for a specific run. A later override creates a new decision event; it does not rewrite the prior evidence. A result can be scientifically eligible yet remain unreviewed. “Validated” is not a runtime state; validation belongs to released components and declared scope.

### 12.2 Scientific-object lifecycle

`DRAFT -> VERIFIED -> RELEASED -> DEPRECATED -> RETIRED`

- Draft objects are mutable and cannot produce authoritative evidence.
- Verified objects passed engineering conformance but may have low scientific evidence.
- Released objects are immutable, signed, scope-declared, and registry-addressable.
- Deprecated objects may replay historical evidence but should not process new sessions after a cutoff.
- Retired objects are preserved for audit but blocked from normal execution.

## 13. Human authority and safety policy

### 13.1 Roles

| Role | May | Must not |
| --- | --- | --- |
| Athlete | See authorized records, provide protocol/context confirmation, exercise data rights. | Alter scientific contracts or practitioner decisions. |
| Operator | Upload, map source fields, manage sessions under policy. | Approve unsupported mappings or scientific releases. |
| S&C coach / sport scientist | Approve protocols, reference epochs, SESOIs, exclusions, and final interpretation. | Represent the output as diagnosis or causal proof. |
| Scientific reviewer | Approve evidence scope and qualification releases. | Approve a build they authored without independent review where policy requires separation. |
| Organization administrator | Assign roles, retention, access, and deployment policy. | Change scientific output or evidence history. |
| Agent | Coordinate approved tools and explain verified results. | Compute, sign, diagnose, prescribe, or silently modify authority-bearing state. |

### 13.2 Required wording discipline

Allowed examples:

- “The session is not comparable because the sampling and processing contract differs from the approved reference.”
- “The estimated decrease is distinguishable from the current measurement model, but practical importance is unresolved because no SESOI is registered.”
- “Evidence supports a decrease exceeding the registered practical threshold with 93% posterior probability.”
- “Retest is recommended because only two valid trials remain.”

Forbidden examples:

- “The athlete is fatigued.”
- “The athlete is not ready.”
- “Yesterday’s training caused the drop.”
- “This pattern indicates injury risk.”
- “Reduce training by 20%.”

## 14. Provenance and evidence contract

The live provenance graph specializes W3C PROV Entity, Activity, and Agent concepts [W12]. The portable evidence output uses an RO-Crate 1.2 / Workflow Run RO-Crate profile [W13]. It contains:

- source artifact and digest;
- canonical acquisition and mapping;
- source and canonical schemas;
- configuration and protocol verdicts;
- processor, metric pack, and inference pack manifests;
- event, quality, metric, session, and inference results;
- model diagnostics and retained stochastic artifacts where required;
- software build provenance and SBOM;
- evidence-scope verification;
- agent trace references, not raw hidden reasoning;
- practitioner decision chronology;
- checksums, signatures, and verification instructions.

Cryptographic signatures prove integrity, identity, and binding of materials to outputs. They do not prove that a formula, reliability claim, SESOI, or causal interpretation is correct.

## 15. Evidence and validation levels

| Tier | Meaning | Minimum evidence |
| --- | --- | --- |
| E0 | Plausibility only | Demonstration; no consequential claim. |
| E1 | Deterministic conformance | Schemas, units, rules, permissions, formulas, and repeatability verified. |
| E2 | Data and measurement validity | Protocol, reliability, agreement, missingness, uncertainty, and population scope evaluated. |
| E3 | Retrospective outcome evaluation | Historical replay with prespecified comparators, leakage controls, and error taxonomy. |
| E4 | Prospective practitioner pilot | Prospective use, adjudication, workflow value, acceptance, overrides, and safety monitored. |
| E5 | External or multisite validation | New organizations, operators, populations, or compatible devices evaluated independently. |

## 16. Validation plan and acceptance gates

### Gate G0 - Workflow evidence

- At least 15 qualified practitioner interviews and 5 observed workflows.
- At least 8 practitioners demonstrate recurring protocol/change adjudication pain.
- At least 5 agree to pilot and at least 3 can supply lawful deidentified raw exports.
- At least 2 credible paid-pilot signals.

### Gate G1 - Contract freeze

- Protocol, configuration identity, event definitions, metric pack, inference estimand, authority, and limitations reviewed by at least two qualified external reviewers.
- Registered deterministic and statistical validation plans.
- Data rights and population scope approved.

### Gate G2 - Adapter and canonical integrity

- Every canonical field maps to source or declared transformation.
- Schema drift and malformed files fail closed.
- Counts, timestamps, units, channel identity, and digests reconcile.
- Unknown preprocessing remains unknown.

### Gate G3 - Deterministic processor verification

- Unit, dimensional, property, boundary, golden-corpus, metamorphic, and adversarial tests pass.
- Event timing and jump-height agreement meet prespecified bounds against an independent reference.
- Repeated runs on the qualified platform are identical.
- No silent exclusion or transformation.

### Gate G4 - Metric and measurement qualification

- Each inferential metric independently meets accepted reliability, agreement, and responsiveness targets under the exact supported scope.
- Sampling-rate and device/configuration equivalence are demonstrated or scope remains separate.
- Failure modes and subgroup limitations are explicit.

### Gate G5 - Statistical calibration

- Simulation-based calibration or appropriate analytic calibration passes.
- Nominal interval coverage and false-escalation rates meet prespecified ranges.
- Prior, baseline, missing-session, outlier, and subgroup sensitivity are acceptable.
- Sparse-baseline behavior fails safely.

### Gate G6 - Practitioner and prospective validation

- Blinded retrospective disposition agreement meets threshold.
- Prospective review time is <=3 minutes median and improves existing workflow materially.
- Zero severe prohibited outputs.
- Every output reproduces from the evidence bundle.
- Continued-use and paid-conversion thresholds are met.

## 17. MVP user experience requirements

1. Upload requires no manual file reformatting for a supported export.
2. Mapping review shows original column, interpreted quantity, unit, plate, axis, and transformation.
3. The trace view shows raw/canonical force, quiet-standing region, detected events, and quality flags.
4. Trial exclusion is never one-click destructive; reason and authority are required.
5. Comparison selection shows why each prior session is eligible or ineligible.
6. Uncertainty is visualized as intervals and probabilities, not red/amber/green readiness.
7. The decision card leads with disposition and evidence, not metric volume.
8. Source, contract, build, and evidence details are one click away.
9. Agent explanation is visually distinguished from verified values.
10. Export includes PDF/HTML report plus machine-readable crate/JSON.

## 18. Risk register

| Risk | Consequence | Control | Kill/reposition trigger |
| --- | --- | --- | --- |
| Vendor export instability | Incorrect mapping or support burden. | Observed-schema fingerprints, fixture corpus, drift detection, adapter qualification. | Vendors prevent lawful raw export or schema cannot be interpreted safely. |
| Metric proliferation | Dashboard-like product and false certainty. | Closed small packs and metric-specific evidence states. | Users value only a large metric menu. |
| Cross-device disagreement | False longitudinal change. | Configuration-specific scopes and bridge studies. | Agreement cannot be bounded for target use. |
| Sparse athlete baselines | Unstable individual inference. | Maturity states, partial pooling, restriction of claims. | Most athletes cannot establish useful baseline in pilot. |
| Protocol metadata missing | False comparability. | Fail closed, human confirmation, capture workflow. | Operational burden exceeds value. |
| Agent overreach | Unsafe explanation or authority bypass. | Typed tools, forbidden-action tests, approval gates, evidence-linked language. | Any severe diagnosis/causality/authority violation. |
| Scientific kernel drift | Historical results change silently. | Immutable releases, replay corpus, semantic version policy. | Cannot reproduce historical evidence. |
| Platform overbuild | Delay without user value. | One CMJ workflow, modular monolith, explicit deferrals. | Architecture work precedes workflow evidence. |
| Low willingness to pay | Calculator commoditization. | Sell adjudication workflow, evidence, onboarding, and cross-vendor independence. | Fewer than 2 of 5 pilots convert. |

## 19. Go / no-go decision

Current disposition:

- **GO:** workflow discovery, export corpus acquisition, protocol review, contract registration, benchmark design, and bounded Eve runtime spike.
- **NO-GO:** production implementation, validation marketing, broad device support, autonomous recommendations, or commercial efficacy claims.

Implementation may begin only when G0 and G1 pass, required raw exports are legally available, and the owner accepts the configuration/sample-rate/metric-pack boundary.

## 20. Requirements traceability

| Concern | Requirements | Primary validation |
| --- | --- | --- |
| Vendor-agnostic ingestion | FR-001 to FR-006 | G2 adapter/canonical integrity |
| Configuration and sampling specificity | FR-007 to FR-010 | G2-G4 |
| Protocol and trial validity | FR-011 to FR-014 | G1-G4 |
| Predetermined metrics | FR-015 to FR-019 | G3-G4 |
| Meaningful-change inference | FR-020 to FR-025 | G4-G5 |
| Evidence and authority | FR-026 to FR-030, FR-037 to FR-040 | G3-G7 |
| Agent safety | FR-031 to FR-036 | G6 plus adversarial evals |
| Quality attributes | NFR-001 to NFR-024 | CI, performance, security, recovery, and pilot evidence |

## 21. Implementation roadmap boundary

1. **A0 - Contract and corpus:** obtain exports, classify configurations, freeze object schemas, register validation plan.
2. **A1 - Reference adapter/canonicalizer:** no UI beyond fixture inspection.
3. **A2 - Deterministic reference kernel:** one protocol, one configuration/sampling contract, one small metric pack.
4. **A3 - Evidence authority and replay:** manifests, provenance, signatures, independent verifier.
5. **A4 - Statistical qualification:** analytic/simple model first; PyMC/Stan comparison only after data design is adequate.
6. **A5 - Practitioner review MVP:** trace review, baseline approval, evidence card, decision record.
7. **A6 - Eve spike and integration:** only after tool contracts exist; qualify approvals, restart, traces, evaluations, and portability.
8. **A7 - Retrospective/prospective validation:** no broad launch before accepted evidence.

## 22. Glossary

| Term | Definition |
| --- | --- |
| Adapter | Source-specific parser and mapper; not a metric authority. |
| Configuration | Exact physical/digital acquisition semantics, including Hz and channels. |
| Protocol | Exact athlete task and collection procedure. |
| Metric pack | Closed, versioned set of eligible metric definitions and aggregation rules. |
| SESOI | Smallest effect size of interest registered for a metric, population, and decision. |
| MDC/SDC | Measurement-error threshold; not automatically practical importance. |
| Evidence authority | Verifier of integrity, scope, policy, and required human authority. |
| Evidence crate | Portable package containing a complete run and its provenance. |
| Comparability regime | Set of sessions allowed to share a reference under qualified equivalence. |

## References and source register

References marked “uploaded” were supplied in the project source set. Web sources were checked on 2026-08-03. Vendor and framework pages establish capabilities and specifications, not independent scientific efficacy.

- **[S01] SportsAgentsLab Master Opportunity, Product Portfolio, and Project Handoff.** SportsAgentsLab internal handoff, research freeze 2026-08-01. Strategic source of truth for product sequence, autonomy, evidence tiers, and human authority. uploaded source
- **[S02] Vladimir M. Zatsiorsky, Kinetics of Human Motion.** Human Kinetics. Newtonian mechanics, external forces, vector analysis, and physical-model discipline. uploaded book
- **[S03] Vladimir M. Zatsiorsky, Kinematics of Human Motion.** Human Kinetics. Coordinate systems, motion representation, velocity, acceleration, and kinematic-chain terminology. uploaded book
- **[S04] Paavo V. Komi (ed.), Strength and Power in Sport, 2nd ed..** IOC Medical Commission / Blackwell Science. SI units and definitions of force, work, power, torque, and stretch-shortening-cycle performance. uploaded book
- **[S05] Zatsiorsky, Kraemer, and Fry, Science and Practice of Strength Training, 3rd ed..** Human Kinetics, 2021. Task specificity, monitoring, testing, and the limits of recipe-style interpretation. uploaded book
- **[S06] Eugene N. Bruce, Biomedical Signal Processing and Signal Modeling.** Wiley, 2001. Signal-model assumptions, desired signal versus noise, measurement-device effects, filtering, and model adequacy. uploaded book
- **[S07] Willis J. Tompkins (ed.), Biomedical Digital Signal Processing.** Prentice Hall, 1993. Sampling, conversion, filtering, signal averaging, real-time DSP, and finite-precision considerations. uploaded book
- **[S08] Tulay Adali and Simon Haykin (eds.), Adaptive Signal Processing.** Wiley, 2010. Robustness under non-Gaussianity, nonstationarity, nonlinearity, and outliers. uploaded book
- **[S09] Joseph D. Bronzino and Donald R. Peterson (eds.), Biomedical Engineering Fundamentals, 4th ed..** CRC Press, 2015. Interdisciplinary engineering, instrumentation, hazards, efficacy, and computational modeling. uploaded book
- **[S10] Jake VanderPlas, Python Data Science Handbook.** O’Reilly, 2017. Python scientific stack and array-oriented data processing. uploaded book
- **[S11] Dan Vanderkam, Effective TypeScript, 2nd ed..** O’Reilly, 2024. Valid-state type design, readonly contracts, schema-derived types, exhaustive checking, and strictness. uploaded book
- **[S12] Durkin, Minick, and Gaikwad, AI-Native Software Delivery.** O’Reilly, 2025. Platform-as-product, progressive delivery, CI/CD governance, SLSA, SBOMs, and observability. uploaded book
- **[W01] Vercel Eve announcement and repository.** Durable sessions, approval gates, typed tools, sandboxing, subagents, traces, evaluations, and beta status. https://vercel.com/blog/introducing-eve ; https://github.com/vercel/eve
- **[W02] ISO/IEC/IEEE 42010:2022.** Requirements for architecture descriptions, concerns, viewpoints, and rationale. https://www.iso.org/standard/74393.html
- **[W03] ISO/IEC 25010:2023.** Product quality model for specifying and evaluating software quality. https://www.iso.org/standard/78176.html
- **[W04] ISO/IEC 25002:2024 and ISO/IEC 25040:2024.** Quality-model usage and evaluation frameworks. https://www.iso.org/standard/78175.html ; https://www.iso.org/committee/45086/x/catalogue/
- **[W05] NIST SP 800-218 SSDF 1.1.** Final secure software development framework. https://csrc.nist.gov/pubs/sp/800/218/final
- **[W06] NIST SP 800-218 Rev. 1 / SSDF 1.2.** Initial public draft; monitored but not treated as final authority. https://csrc.nist.gov/pubs/sp/800/218/r1/ipd
- **[W07] NIST SP 800-218A.** Secure software development practices for generative AI and dual-use foundation models. https://csrc.nist.gov/pubs/sp/800/218/a/final
- **[W08] OWASP ASVS 5.0.0.** Application-security verification baseline. https://owasp.org/www-project-application-security-verification-standard/
- **[W09] OWASP LLM Verification Standard 2.0.** 2026 verification requirements for LLM-enabled systems. https://owasp.org/www-project-llm-verification-standard/LLMSVS-v2.0-en.html
- **[W10] SLSA specification 1.2.** Software artifact provenance and build integrity. https://slsa.dev/spec/v1.2/
- **[W11] Sigstore Cosign documentation.** Keyless artifact and blob signing, certificates, transparency log, and verification bundles. https://docs.sigstore.dev/quickstart/quickstart-cosign/
- **[W12] W3C PROV-O.** Domain-independent provenance ontology based on Entity, Activity, and Agent. https://www.w3.org/TR/prov-o/
- **[W13] RO-Crate 1.2 and Workflow Run RO-Crate.** Portable file-oriented research-object and computational-run packaging. https://www.researchobject.org/ro-crate/specification/1.2/ ; https://www.researchobject.org/workflow-run-crate/
- **[W14] JCGM 100:2008 GUM and JCGM GUM-1:2023.** Expression and evaluation of measurement uncertainty. https://www.bipm.org/en/committees/jc/jcgm/publications
- **[W15] JCGM 200:2012 VIM.** International vocabulary of metrology. https://www.bipm.org/en/committees/jc/jcgm/publications
- **[W16] C3D force-platform specification.** Force-platform type, channel, geometry, origin, and calibration-matrix semantics; Type 4 is not “4D”. https://www.c3d.org/HTML/Documents/forceplatformtype.htm
- **[W17] UCUM.** Unambiguous machine-readable unit representation. https://ucum.org/ucum
- **[W18] JSON Schema 2020-12.** Canonical schema and validation vocabulary. https://json-schema.org/draft/2020-12
- **[W19] OpenAPI 3.2.0.** Current API description standard; tooling compatibility must be qualified. https://spec.openapis.org/oas/v3.2.0.html
- **[W20] Apache Arrow and Parquet.** Cross-language columnar memory model and durable columnar storage. https://arrow.apache.org/docs/format/Columnar.html ; https://parquet.apache.org/docs/
- **[W21] PostgreSQL 18.4.** Current PostgreSQL documentation and supported release. https://www.postgresql.org/docs/current/
- **[W22] Python 3.14.6 and Python 3.13.14.** Current stable and conservative scientific-runtime qualification targets. https://www.python.org/downloads/
- **[W23] Node.js releases.** Production applications should use Active or Maintenance LTS; Node 24 is the selected baseline. https://nodejs.org/en/about/previous-releases
- **[W24] TypeScript 6.0 and 5.9 documentation.** 6.0 is a transition release; 5.9 remains the initial compatibility baseline pending dependency qualification. https://www.typescriptlang.org/docs/handbook/release-notes/typescript-6-0.html
- **[W25] FastAPI and Pydantic.** Typed Python API and runtime-validation candidates. https://fastapi.tiangolo.com/ ; https://docs.pydantic.dev/latest/
- **[W26] PyMC 6.2 documentation.** Primary candidate for hierarchical Bayesian model development and production inference. https://docs.pymc.io/
- **[W27] Stan 2.39 / CmdStan.** Independent statistical oracle and reference implementation candidate. https://mc-stan.org/docs/reference-manual/ ; https://mc-stan.org/tools/
- **[W28] Temporal documentation.** Durable workflow execution, retries, timers, and human wait states. https://docs.temporal.io/
- **[W29] OpenTelemetry documentation.** Vendor-neutral traces, metrics, logs, OTLP, and collector. https://opentelemetry.io/docs/
- **[W30] Countermovement jump metric reliability review.** Metric dimensionality and reliability vary; supports a deliberately small qualified pack. https://pmc.ncbi.nlm.nih.gov/articles/PMC9865236/
- **[W31] Merrigan et al., CMJ force-time reliability and comparability across force-plate systems.** Supports device/configuration-specific agreement qualification. https://pubmed.ncbi.nlm.nih.gov/37815253/
- **[W32] Hori et al., reliability and sampling frequency.** Sampling frequency affects some derived outcomes and must be a contract dimension. https://ro.ecu.edu.au/cgi/viewcontent.cgi?article=1506&context=ecuworks
- **[W33] Meylan et al., CMJ movement-onset thresholds.** Event definitions materially affect results and must be frozen and tested. https://pubmed.ncbi.nlm.nih.gov/20664368/
- **[W34] Reliability of vertical-jump force-time metrics in collegiate athletes.** Recent evidence that reliability is metric-specific, not guaranteed by hardware capability. https://pmc.ncbi.nlm.nih.gov/articles/PMC12733763/
