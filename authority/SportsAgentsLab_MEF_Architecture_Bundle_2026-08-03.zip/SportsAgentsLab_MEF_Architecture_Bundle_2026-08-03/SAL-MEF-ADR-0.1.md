---
title: "Architecture Decision Record Compendium"
subtitle: "SportsAgentsLab Measurement Evidence Factory"
author: "SportsAgentsLab"
date: "2026-08-03"
lang: en-US
---

# Architecture Decision Record Compendium

**Document ID:** `SAL-MEF-ADR-0.1`  
**Version:** `0.1.0`  
**Status:** `CURATED_BASELINE_FOR_OWNER_REVIEW`  
**Research freeze:** 2026-08-03  
**Implementation authority:** Not granted by this document  
**Purpose:** Record the major architectural and scientific-software decisions, rationale, consequences, rejected alternatives, and review triggers for the Measurement Evidence Factory.

> **Normative language.** “MUST”, “MUST NOT”, “SHOULD”, “SHOULD NOT”, and “MAY” are used as requirements terms. A requirement is not scientifically qualified merely because it appears here. Scientific claims advance only through the defined evidence gates.

> **Safety boundary.** The system does not diagnose injury, infer unsupported training causality, clear an athlete, prescribe medical action, or conceal uncertainty behind generic readiness labels. Qualified practitioners retain final interpretation.


## 1. Decision-record policy

This compendium uses one ADR per durable decision. “Accepted” means the decision is the current design baseline, not that implementation or scientific qualification is complete. “Accepted with qualification” means the direction is selected but a named spike or gate can still reject the specific technology. Superseded ADRs remain in history.

Each decision is evaluated against the following priorities, in order:

1. scientific validity and transparent limitations;
2. evidence integrity and human authority;
3. reproducibility and independent verification;
4. maintainability for a small technical/scientific team;
5. security and athlete-data governance;
6. practitioner workflow value;
7. scalability and cost efficiency;
8. framework novelty.

The master handoff explicitly subordinates platform building to one proven workflow and separates LLM functions from scientific computation [S01]. These ADRs implement that boundary.

## 2. Decision index

| ID | Decision | Status |
| --- | --- | --- |
| ADR-001 | Use a modular monolith plus isolated scientific workers | Accepted |
| ADR-002 | Be vendor-agnostic but configuration-specific | Accepted |
| ADR-003 | Adopt native-export-first ingestion | Accepted |
| ADR-004 | Preserve raw source artifacts immutably | Accepted |
| ADR-005 | Use JSON Schema 2020-12 as contract authority | Accepted |
| ADR-006 | Use OpenAPI for service APIs with generated clients | Accepted with qualification |
| ADR-007 | Use Python for the scientific kernel | Accepted |
| ADR-008 | Use TypeScript for the control and practitioner plane | Accepted |
| ADR-009 | Freeze conservative runtime versions and maintain qualification lanes | Accepted |
| ADR-010 | Store operational state in PostgreSQL | Accepted |
| ADR-011 | Store high-rate signals and evidence in object storage using Parquet/Arrow | Accepted |
| ADR-012 | Use a small authoritative deterministic processor | Accepted |
| ADR-013 | Use closed, versioned, code-backed metric packs | Accepted |
| ADR-014 | Make sample rate and preprocessing explicit eligibility dimensions | Accepted |
| ADR-015 | Use a framework-neutral inference port with analytic-first implementation | Accepted |
| ADR-016 | Use practitioner-approved fixed reference epochs | Accepted |
| ADR-017 | Separate measurement error from practical importance | Accepted |
| ADR-018 | Use W3C PROV plus RO-Crate for provenance and portable evidence | Accepted |
| ADR-019 | Create a separate Evidence Authority | Accepted |
| ADR-020 | Separate build, scientific, runtime, practitioner, and organization authority | Accepted |
| ADR-021 | Use SLSA-compatible build provenance and Sigstore signing | Accepted |
| ADR-022 | Use Temporal for durable workflows after the workflow gate | Accepted with staged adoption |
| ADR-023 | Qualify Eve behind an agent-runtime adapter | Accepted for spike, not production commitment |
| ADR-024 | Keep raw athlete signals out of LLM context by default | Accepted |
| ADR-025 | Use OIDC, RBAC plus ABAC, and PostgreSQL RLS | Accepted |
| ADR-026 | Use OpenTelemetry and OTLP | Accepted |
| ADR-027 | Do not adopt Kubernetes initially | Accepted |
| ADR-028 | Use transactional outbox, not full event sourcing | Accepted |
| ADR-029 | Use no generic readiness score and no unsupported causal attribution | Accepted |
| ADR-030 | Treat architecture and scientific documents as versioned release artifacts | Accepted |

# ADR-001: Use a modular monolith plus isolated scientific workers

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

The project is a small-team, scientifically governed product. Premature microservices would multiply deployment, schema, observability, and consistency failure modes.

## Decision

Keep one repository and one control-plane application with bounded modules. Deploy adapter, processor, inference, and evidence workers separately only where isolation, runtime, scaling, or security require it.

## Rationale

The architecture must keep scientific boundaries visible without forcing a small team to operate a distributed platform. A modular monolith can enforce package boundaries and transactions while isolated workers provide the runtime and security separation that is actually required.

## Consequences

Lower cognitive load; transactional consistency for authority state; independent scientific execution. Some components may later be extracted by measured pressure.

## Alternatives rejected

Microservices from day one; one-process monolith; serverless functions for every step..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit when team/service ownership, independent scaling, multi-region, or deployment cadence demonstrates a concrete need.

---

# ADR-002: Be vendor-agnostic but configuration-specific

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Vendor brands and “2D/3D/4D” labels do not uniquely define physical channels, coordinates, sample timing, calibration, or preprocessing.

## Decision

Adapters terminate vendor concerns. Scientific eligibility is keyed by exact configuration, protocol, sample rate, preprocessing state, population, and metric pack.

## Rationale

Force-plate capability follows physical channels, coordinate and calibration semantics, timing, and preprocessing. Vendor labels are insufficient and can be actively misleading, as illustrated by C3D Type 4 semantics [W16].

## Consequences

Prevents false equivalence and enables cross-vendor expansion. Requires more qualification objects and conservative support.

## Alternatives rejected

Vendor-specific products; brand-only compatibility; one universal force-plate schema without qualification..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit only if an industry standard fully captures required source semantics and vendors conform.

---

# ADR-003: Adopt native-export-first ingestion

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

User-owned exports are accessible before APIs and avoid early enterprise integration dependency.

## Decision

Support exact observed CSV/XLSX/JSON/C3D surfaces through versioned adapters; add APIs after export workflow value is validated.

## Rationale

The strategic wedge depends on practitioner-owned data access. Export-native support proves demand before API contracts, procurement, and vendor partnerships become dependencies.

## Consequences

Faster discovery and lower vendor dependency. Batch/manual workflow remains until connectors are justified.

## Alternatives rejected

API-first; proprietary ingestion agent; require users to convert to our template..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit when pilot use proves recurring volume and vendors provide stable lawful APIs.

---

# ADR-004: Preserve raw source artifacts immutably

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Evidence must remain auditable even when adapters and processors evolve.

## Decision

Hash and store exact received bytes before parsing. Never replace an accepted source object; corrections create new artifacts and links.

## Rationale

A canonical representation is an interpretation. Without original bytes, later scientific or adapter corrections cannot be audited.

## Consequences

Strong provenance and replay. Storage and retention governance become first-class costs.

## Alternatives rejected

Store only canonical data; overwrite corrected files; trust vendor cloud links..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Never, except cryptographic algorithm migration with retained old digest mapping.

---

# ADR-005: Use JSON Schema 2020-12 as contract authority

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Cross-language hand-written models drift and TypeScript types do not validate runtime input.

## Decision

Author domain schemas in JSON Schema; generate TypeScript/Python models and API projections.

## Rationale

A schema-first contract supports both static type safety and runtime validation. Effective TypeScript recommends generating types from authoritative schemas and designing types that represent valid states [S11].

## Consequences

One semantic source, runtime validation, contract testing. Requires code generation discipline and schema governance.

## Alternatives rejected

OpenAPI as sole authority; Protobuf; hand-written Pydantic and TS interfaces..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit if binary streaming or external interoperability requires a second canonical IDL.

---

# ADR-006: Use OpenAPI for service APIs with generated clients

**Status:** `ACCEPTED_WITH_QUALIFICATION`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Typed service boundaries and external integration require discoverable contracts.

## Decision

Target OpenAPI 3.2; generate and test a 3.1 compatibility projection until tooling is proven.

## Rationale

REST resources and workflow commands are understandable to partner systems and allow standard security/tooling. Domain semantics remain decoupled from API-description limitations.

## Consequences

Stable API documentation and clients without changing domain schema authority.

## Alternatives rejected

GraphQL; handwritten REST; gRPC everywhere..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit per external partner needs and generator maturity.

---

# ADR-007: Use Python for the scientific kernel

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

NumPy/SciPy, biomechanics workflows, Bayesian libraries, and founder expertise make Python the maintainable scientific substrate.

## Decision

Implement pure typed Python libraries for acquisition mechanics, event detection, metrics, and inference ports.

## Rationale

The scientific ecosystem and available expertise outweigh the theoretical performance advantages of a lower-level language for the initial workload. Native acceleration remains possible behind tested functions.

## Consequences

Scientific ecosystem and inspectability. Requires strict discipline to prevent notebook/runtime drift.

## Alternatives rejected

TypeScript-only; Rust-first; MATLAB production runtime..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit hotspots only after profiling and conformance tests support native acceleration.

---

# ADR-008: Use TypeScript for the control and practitioner plane

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

The web, Eve candidate, workflow tools, and typed authority UI favor TypeScript, while scientific computation should remain separate.

## Decision

Use Node 24 LTS and strict TypeScript with generated contracts for control API, UI, policy, and runtime adapters.

## Rationale

The control plane benefits from strong UI/API typing and direct compatibility with Eve while avoiding contamination of scientific code by web-framework concerns.

## Consequences

Strong web ergonomics and valid-state design. Cross-language contract generation becomes essential.

## Alternatives rejected

Python full stack; Java/Kotlin; Bun-only stack..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit if operational scale or team composition materially changes.

---

# ADR-009: Freeze conservative runtime versions and maintain qualification lanes

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Latest language releases may outpace scientific or agent dependencies.

## Decision

Production begins on Python 3.13.14, Node 24 LTS, and TypeScript 5.9; CI qualifies Python 3.14 and TypeScript 6 before promotion.

## Rationale

Reliability requires a deliberate upgrade policy. Node itself recommends LTS for production [W23], while TypeScript 6.0 is explicitly transitional [W24].

## Consequences

Reliability with visible upgrade path. Additional CI matrix cost.

## Alternatives rejected

Always latest; indefinite old versions..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Review quarterly and on security/end-of-support events.

---

# ADR-010: Store operational state in PostgreSQL

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

The domain needs transactions, constraints, audit relationships, JSON, and tenant isolation.

## Decision

Use managed PostgreSQL 18 with explicit SQL/migrations, RLS, and transactional outbox.

## Rationale

Authority and evidence state require database-enforced invariants and transactions. PostgreSQL provides these without introducing a second operational database [W21].

## Consequences

Mature correctness and operations. Avoids unnecessary polyglot persistence.

## Alternatives rejected

Document database; event store as sole system; SQLite production..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit only for measured bottlenecks not solvable by indexing/partitioning/replicas.

---

# ADR-011: Store high-rate signals and evidence in object storage using Parquet/Arrow

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Sample-per-row relational storage is inefficient; arrays need cross-language fidelity.

## Decision

Use immutable S3-compatible objects and canonical Parquet with Arrow schemas.

## Rationale

Arrow/Parquet is a better semantic and performance fit for dense time-series arrays than sample-per-row OLTP storage [W20].

## Consequences

Compact, scalable, portable. Requires careful schema/version and metadata design.

## Alternatives rejected

Postgres arrays/rows; HDF5-only; proprietary binary blobs..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit after interoperability and performance benchmarks.

---

# ADR-012: Use a small authoritative deterministic processor

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Scientific authority cannot be a loose set of notebooks or vendor calculations.

## Decision

Maintain a small pure kernel with explicit formulas, transformations, events, and trace output; compare against independent implementations.

## Rationale

Biomedical signal processing requires explicit assumptions about source, noise, sampling, and model adequacy [S06]. A small kernel makes those assumptions reviewable.

## Consequences

Reviewable and reproducible. More work than wrapping vendor results.

## Alternatives rejected

Vendor metrics; broad open-source library as unqualified authority; LLM calculation..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit per metric only after qualification.

---

# ADR-013: Use closed, versioned, code-backed metric packs

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Arbitrary metric menus create false validity and uncontrolled semantics.

## Decision

Metric packs activate a predetermined set of code-backed definitions under exact eligibility conditions.

## Rationale

A closed pack converts “metric available” into a governed scientific claim. This addresses the documented variability and redundancy of CMJ metrics [W30, W34].

## Consequences

Clear scientific scope and manageable UX. Users cannot freely create authoritative formulas.

## Alternatives rejected

Dynamic expression language; calculate every available metric; vendor metric menus..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit through Methodology Studio only after first-party packs prove governance.

---

# ADR-014: Make sample rate and preprocessing explicit eligibility dimensions

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Sampling and filtering can change event timing and derived metrics.

## Decision

No silent resampling/filtering. Each supported rate/preprocessing state is qualified or covered by an accepted equivalence study.

## Rationale

Sampling frequency and preprocessing can alter derived measurements. Qualification must bind the exact acquisition contract [W32].

## Consequences

Defensible comparisons; more qualification burden.

## Alternatives rejected

Normalize everything to 1,000 Hz; ignore vendor filtering; infer time from rows..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit when empirical equivalence evidence supports broader contracts.

---

# ADR-015: Use a framework-neutral inference port with analytic-first implementation

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

A complex Bayesian runtime should not be adopted before the estimand and data support it.

## Decision

Implement the simplest calibrated model first; benchmark PyMC as primary candidate and Stan as independent oracle behind an `InferenceRuntime` port.

## Rationale

The inference engine is an implementation choice, not the estimand. Keeping a port enables simple analytic methods, PyMC, and Stan to be compared without changing product semantics [W26, W27].

## Consequences

Avoids unnecessary complexity while preserving rigorous path. Multiple implementation cost during qualification.

## Alternatives rejected

PyMC-only from day one; Stan-only production; classical thresholds only..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Review after G4/G5 validation data and latency benchmark.

---

# ADR-016: Use practitioner-approved fixed reference epochs

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Silent rolling baselines can erase real changes and change the estimand.

## Decision

Reference sessions are explicitly selected, versioned, and approved. Rolling/adaptive references require a separate inference contract.

## Rationale

Reference selection changes the question being answered. It is therefore an authority-bearing scientific decision, not a background convenience.

## Consequences

Stable interpretation and auditability. More practitioner setup.

## Alternatives rejected

Automatic rolling window; universal preseason baseline; group normative baseline..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit through qualified alternative reference policies.

---

# ADR-017: Separate measurement error from practical importance

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

MDC/SDC and a SESOI answer different questions.

## Decision

Inference outputs distinguish validity, statistical distinguishability, and practical threshold exceedance. No SESOI means no “meaningful” claim.

## Rationale

Metrological uncertainty and practical importance are conceptually distinct [W14, W15]. Combining them produces misleading certainty.

## Consequences

Honest uncertainty and decision semantics. Some users may perceive less simplicity.

## Alternatives rejected

Single red/green threshold; group z-score; 0.2 SD default..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Never as a principle; individual methods can evolve.

---

# ADR-018: Use W3C PROV plus RO-Crate for provenance and portable evidence

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Evidence must be machine-readable, interoperable, and independently inspectable.

## Decision

Specialize PROV entities/activities/agents in the live model and export a SportsAgentsLab RO-Crate/Workflow Run profile.

## Rationale

PROV and RO-Crate provide established vocabulary and portable packaging, reducing the risk of an unreadable proprietary evidence archive [W12, W13].

## Consequences

Standards-based portability. Mapping complexity and profile maintenance.

## Alternatives rejected

Custom JSON only; OpenLineage as complete evidence; database dump..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Review profile after external verifier feedback.

---

# ADR-019: Create a separate Evidence Authority

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Calculation services, agent, and UI should not self-declare scientific eligibility.

## Decision

A policy-controlled verifier checks integrity, lifecycle, scope, diagnostics, and required human authority before issuing status/attestation.

## Rationale

A verifier that is independent of computation and narration makes evidence status testable and prevents the agent from upgrading its own authority.

## Consequences

Separation of duties and clear claims. Additional service/policy complexity.

## Alternatives rejected

Trust processor output; agent-generated status; blockchain consensus..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Review service boundary, not the authority concept.

---

# ADR-020: Separate build, scientific, runtime, practitioner, and organization authority

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

A single signer cannot represent independent meanings.

## Decision

Use distinct identities/predicates and verification policies for each authority class.

## Rationale

The meanings of “this binary was built”, “this method is qualified”, “this run occurred”, and “this practitioner accepted it” are not interchangeable.

## Consequences

Prevents overbroad trust and improves audit. Key and policy management cost.

## Alternatives rejected

One organization key; unsigned practitioner clicks; shared service account..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Review cryptographic mechanism, not separation principle.

---

# ADR-021: Use SLSA-compatible build provenance and Sigstore signing

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Scientific replay depends on authentic software artifacts and dependencies.

## Decision

CI produces SBOM and SLSA provenance; Cosign signs images, packages, and evidence/release bundles.

## Rationale

SLSA and Sigstore provide direct attestations rather than trust inferred from deployment context [W10, W11].

## Consequences

Verifiable supply chain and tamper evidence. Private/offline profile needed.

## Alternatives rejected

Checksums only; manual release signing; no provenance..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Review as SLSA/Sigstore standards evolve.

---

# ADR-022: Use Temporal for durable workflows after the workflow gate

**Status:** `ACCEPTED_WITH_STAGED_ADOPTION`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Imports, retries, inference, evidence assembly, and human approvals can outlive requests and process restarts.

## Decision

Adopt Temporal when the first end-to-end workflow exists; keep activity payloads reference-based and workflow code deterministic.

## Rationale

Durable waits and retries are a real product need once human approvals and long computations exist, but adopting a workflow engine before that point would be platform-first overbuild.

## Consequences

Reliable wait/retry state. Operational and conceptual overhead.

## Alternatives rejected

Database cron/state machine; queues only; Eve as system workflow engine..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Defer if a simpler state machine satisfies pilot reliability.

---

# ADR-023: Qualify Eve behind an agent-runtime adapter

**Status:** `ACCEPTED_FOR_SPIKE,_NOT_PRODUCTION_COMMITMENT`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Eve aligns with durable sessions and approvals but is beta and may change.

## Decision

Build exact bounded spike after tool contracts; retain independent `MeasurementAgentRuntime`.

## Rationale

Eve is promising because its durable session and approval model matches the use case [W01]. Beta status and framework churn make an adapter and explicit qualification mandatory.

## Consequences

Can leverage strong agent ergonomics without scientific lock-in. Adapter work and duplicate state concerns.

## Alternatives rejected

Commit directly to Eve; reject all frameworks; custom agent runtime now..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Production adoption only after explicit spike pass.

---

# ADR-024: Keep raw athlete signals out of LLM context by default

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

High-rate data is unnecessary for most orchestration and increases privacy/cost risk.

## Decision

Expose typed summaries, flags, evidence references, and downsampled review assets only when authorized.

## Rationale

The agent can reason over evidence references and structured summaries. Sending high-rate signals increases exposure without corresponding authority or reliability.

## Consequences

Data minimization and lower cost. Agent cannot inspect arbitrary raw trace.

## Alternatives rejected

Send CSV to model; local code interpreter over raw data..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit narrowly for validated visual reasoning use cases.

---

# ADR-025: Use OIDC, RBAC plus ABAC, and PostgreSQL RLS

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Role alone is insufficient for organization, purpose, athlete, and evidence-state restrictions.

## Decision

OIDC identity, role capabilities, contextual policy, and database RLS defense in depth.

## Rationale

Purpose, athlete scope, and evidence state are contextual. Combining RBAC, ABAC, and RLS provides layered enforcement.

## Consequences

Strong tenant isolation and purpose control. More policy testing.

## Alternatives rejected

RBAC only; application checks only; separate DB per user..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit tenancy topology at enterprise scale.

---

# ADR-026: Use OpenTelemetry and OTLP

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Cross-runtime workflow and scientific execution require correlation without vendor lock-in.

## Decision

Instrument control, workflow, workers, and evidence assembly with OTel; prohibit sensitive raw data in telemetry.

## Rationale

OpenTelemetry is vendor-neutral and spans Python, Node, workflows, and asynchronous producer/consumer relationships [W29].

## Consequences

Portable observability and run correlation. Semantic convention governance needed.

## Alternatives rejected

Vendor SDKs directly; logs only; custom tracing..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Review backend, not instrumentation standard.

---

# ADR-027: Do not adopt Kubernetes initially

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

The initial service count and scale do not justify cluster operational cost.

## Decision

Use managed containers, managed Postgres/object storage, and autoscaled worker pools.

## Rationale

Kubernetes is an operating model, not a badge of scalability. Managed containers preserve a scale path without cluster toil.

## Consequences

Lower operational burden and faster pilot. Less scheduling flexibility.

## Alternatives rejected

Kubernetes from day one; serverless-only..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit when measured scale, specialized compute, multi-region, or platform-team needs justify it.

---

# ADR-028: Use transactional outbox, not full event sourcing

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

Audit and integration events are necessary, but rebuilding all state from events adds complexity.

## Decision

PostgreSQL remains system of record; append audit events and publish via transactional outbox.

## Rationale

The product needs immutable evidence and audit chronology, but most operational queries are naturally relational. The outbox pattern preserves reliable events without imposing event-sourced reconstruction.

## Consequences

Reliable integration with simpler queries and migrations. Some dual representation.

## Alternatives rejected

Full event sourcing; direct queue publish; mutable audit columns..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Revisit if temporal reconstruction becomes the dominant product capability.

---

# ADR-029: Use no generic readiness score and no unsupported causal attribution

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

A composite label hides measurement, model, and decision uncertainty and invites misuse.

## Decision

Product states are measurement-validity, comparability, distinguishability, practical-threshold, and human disposition states only.

## Rationale

The product contract is measurement adjudication. Generic state labels and causal narratives exceed the available evidence and violate the master boundary [S01].

## Consequences

Scientifically honest and aligned with authority boundary. Less marketable simplification.

## Alternatives rejected

Red/amber/green readiness; causal narrative from correlations..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Never without a separate scientifically and ethically qualified product contract.

---

# ADR-030: Treat architecture and scientific documents as versioned release artifacts

**Status:** `ACCEPTED`  
**Date:** 2026-08-03  
**Decision owner:** SportsAgentsLab founder / architecture authority  
**Scope:** Measurement Evidence Factory v0.x

## Context

The system cannot be maintained if rationale and contracts drift from implementation.

## Decision

Store SDD, TDD, ADRs, schemas, validation plans, and source register in the repository; releases bind document digests.

## Rationale

Architecture decisions, schemas, and scientific claims are part of the evidence chain. Treating them as versioned artifacts keeps implementation and declared authority aligned.

## Consequences

Traceable evolution and review. Documentation maintenance is required work.

## Alternatives rejected

External wiki only; code as documentation; one frozen design forever..

## Verification and enforcement

- Encode the boundary in schemas, package/dependency rules, policy tests, and CI where applicable.
- Add at least one positive conformance test and one negative/adversarial test.
- Bind the ADR ID to relevant manifests, source modules, and validation reports.
- A production exception requires a recorded waiver with owner, expiry, evidence impact, and rollback.

## Review trigger

Review at every material architectural or scientific boundary change.

---


## 3. Cross-decision consistency rules

1. No technology ADR can weaken the scientific or authority boundary defined by ADR-002, ADR-012 through ADR-020, or ADR-029.
2. A new vendor adapter cannot imply a new scientific qualification.
3. A schema/API change cannot reinterpret historic evidence in place.
4. An agent or workflow framework may be replaced without changing scientific packages or evidence semantics.
5. Scaling decisions require measured bottlenecks and may not move raw sensitive data into less controlled services.
6. A simpler implementation is preferred when it satisfies the same evidence and safety contract.
7. Every superseding ADR must identify affected releases and replay implications.

## 4. Open decisions not yet accepted

- Exact first two vendor/export surfaces.
- Exact first qualified sample-rate set.
- Final event thresholds and filtering policy.
- PyMC versus analytic production inference runtime.
- Managed Temporal versus self-hosted profile.
- Exact hosting provider and regional data-residency profile.
- Public versus private registry and Sigstore trust model.
- Exact SESOI governance for the first population and metric.
- Whether C3D is MVP input or post-MVP interoperability.

These are intentionally unresolved because they require data, compatibility, operational, or scientific evidence rather than architectural preference.

## References and source register

References marked “uploaded” were supplied in the project source set. Web sources were checked on 2026-08-03. Vendor and framework pages establish capabilities and specifications, not independent scientific efficacy.

- **[S01] SportsAgentsLab Master Opportunity, Product Portfolio, and Project Handoff.** SportsAgentsLab internal handoff, research freeze 2026-08-01. Strategic source of truth for product sequence, autonomy, evidence tiers, and human authority. uploaded source
- **[S02] Vladimir M. Zatsiorsky, Kinetics of Human Motion.** Human Kinetics. Newtonian mechanics, external forces, vector analysis, and physical-model discipline. uploaded book
- **[S03] Vladimir M. Zatsiorsky, Kinematics of Human Motion.** Human Kinetics. Coordinate systems, motion representation, velocity, acceleration, and kinematic-chain terminology. uploaded book
- **[S04] Paavo V. Komi (ed.), Strength and Power in Sport, 2nd ed..** IOC Medical Commission / Blackwell Science. SI units and definitions of force, work, power, torque, and stretch-shortening-cycle performance. uploaded book
- **[S05] Zatsiorsky, Kraemer, and Fry, Science and Practice of Strength Training, 3rd ed..** Human Kinetics, 2021. Task specificity, monitoring, testing, and the limits of recipe-style interpretation. uploaded book
- **[S06] Eugene N. Bruce, Biomedical Signal Processing and Signal Modeling.** Wiley, 2001. Signal-model assumptions, desired signal versus noise, measurement-device effects, filtering, and model adequacy. uploaded book
- **[S07] Willis J. Tompkins (ed.), Biomedical Digital Signal Processing.** Prentice Hall, 1993. Sampling, conversion, filtering, signal averaging, real-time DSP, and finite-precision considerations. uploaded book
- **[S08] Tulay Adali and Simon Haykin (eds.), Adaptive Signal Processing.** Wiley, 2010. Robustness under non-Gaussianity, nonstationarity, nonlinearity, and outliers. uploaded book
- **[S09] Joseph D. Bronzino and Donald R. Peterson (eds.), Biomedical Engineering Fundamentals, 4th ed..** CRC Press, 2015. Interdisciplinary engineering, instrumentation, hazards, efficacy, and computational modeling. uploaded book
- **[S10] Jake VanderPlas, Python Data Science Handbook.** O’Reilly, 2017. Python scientific stack and array-oriented data processing. uploaded book
- **[S11] Dan Vanderkam, Effective TypeScript, 2nd ed..** O’Reilly, 2024. Valid-state type design, readonly contracts, schema-derived types, exhaustive checking, and strictness. uploaded book
- **[S12] Durkin, Minick, and Gaikwad, AI-Native Software Delivery.** O’Reilly, 2025. Platform-as-product, progressive delivery, CI/CD governance, SLSA, SBOMs, and observability. uploaded book
- **[W01] Vercel Eve announcement and repository.** Durable sessions, approval gates, typed tools, sandboxing, subagents, traces, evaluations, and beta status. https://vercel.com/blog/introducing-eve ; https://github.com/vercel/eve
- **[W02] ISO/IEC/IEEE 42010:2022.** Requirements for architecture descriptions, concerns, viewpoints, and rationale. https://www.iso.org/standard/74393.html
- **[W03] ISO/IEC 25010:2023.** Product quality model for specifying and evaluating software quality. https://www.iso.org/standard/78176.html
- **[W04] ISO/IEC 25002:2024 and ISO/IEC 25040:2024.** Quality-model usage and evaluation frameworks. https://www.iso.org/standard/78175.html ; https://www.iso.org/committee/45086/x/catalogue/
- **[W05] NIST SP 800-218 SSDF 1.1.** Final secure software development framework. https://csrc.nist.gov/pubs/sp/800/218/final
- **[W06] NIST SP 800-218 Rev. 1 / SSDF 1.2.** Initial public draft; monitored but not treated as final authority. https://csrc.nist.gov/pubs/sp/800/218/r1/ipd
- **[W07] NIST SP 800-218A.** Secure software development practices for generative AI and dual-use foundation models. https://csrc.nist.gov/pubs/sp/800/218/a/final
- **[W08] OWASP ASVS 5.0.0.** Application-security verification baseline. https://owasp.org/www-project-application-security-verification-standard/
- **[W09] OWASP LLM Verification Standard 2.0.** 2026 verification requirements for LLM-enabled systems. https://owasp.org/www-project-llm-verification-standard/LLMSVS-v2.0-en.html
- **[W10] SLSA specification 1.2.** Software artifact provenance and build integrity. https://slsa.dev/spec/v1.2/
- **[W11] Sigstore Cosign documentation.** Keyless artifact and blob signing, certificates, transparency log, and verification bundles. https://docs.sigstore.dev/quickstart/quickstart-cosign/
- **[W12] W3C PROV-O.** Domain-independent provenance ontology based on Entity, Activity, and Agent. https://www.w3.org/TR/prov-o/
- **[W13] RO-Crate 1.2 and Workflow Run RO-Crate.** Portable file-oriented research-object and computational-run packaging. https://www.researchobject.org/ro-crate/specification/1.2/ ; https://www.researchobject.org/workflow-run-crate/
- **[W14] JCGM 100:2008 GUM and JCGM GUM-1:2023.** Expression and evaluation of measurement uncertainty. https://www.bipm.org/en/committees/jc/jcgm/publications
- **[W15] JCGM 200:2012 VIM.** International vocabulary of metrology. https://www.bipm.org/en/committees/jc/jcgm/publications
- **[W16] C3D force-platform specification.** Force-platform type, channel, geometry, origin, and calibration-matrix semantics; Type 4 is not “4D”. https://www.c3d.org/HTML/Documents/forceplatformtype.htm
- **[W17] UCUM.** Unambiguous machine-readable unit representation. https://ucum.org/ucum
- **[W18] JSON Schema 2020-12.** Canonical schema and validation vocabulary. https://json-schema.org/draft/2020-12
- **[W19] OpenAPI 3.2.0.** Current API description standard; tooling compatibility must be qualified. https://spec.openapis.org/oas/v3.2.0.html
- **[W20] Apache Arrow and Parquet.** Cross-language columnar memory model and durable columnar storage. https://arrow.apache.org/docs/format/Columnar.html ; https://parquet.apache.org/docs/
- **[W21] PostgreSQL 18.4.** Current PostgreSQL documentation and supported release. https://www.postgresql.org/docs/current/
- **[W22] Python 3.14.6 and Python 3.13.14.** Current stable and conservative scientific-runtime qualification targets. https://www.python.org/downloads/
- **[W23] Node.js releases.** Production applications should use Active or Maintenance LTS; Node 24 is the selected baseline. https://nodejs.org/en/about/previous-releases
- **[W24] TypeScript 6.0 and 5.9 documentation.** 6.0 is a transition release; 5.9 remains the initial compatibility baseline pending dependency qualification. https://www.typescriptlang.org/docs/handbook/release-notes/typescript-6-0.html
- **[W25] FastAPI and Pydantic.** Typed Python API and runtime-validation candidates. https://fastapi.tiangolo.com/ ; https://docs.pydantic.dev/latest/
- **[W26] PyMC 6.2 documentation.** Primary candidate for hierarchical Bayesian model development and production inference. https://docs.pymc.io/
- **[W27] Stan 2.39 / CmdStan.** Independent statistical oracle and reference implementation candidate. https://mc-stan.org/docs/reference-manual/ ; https://mc-stan.org/tools/
- **[W28] Temporal documentation.** Durable workflow execution, retries, timers, and human wait states. https://docs.temporal.io/
- **[W29] OpenTelemetry documentation.** Vendor-neutral traces, metrics, logs, OTLP, and collector. https://opentelemetry.io/docs/
- **[W30] Countermovement jump metric reliability review.** Metric dimensionality and reliability vary; supports a deliberately small qualified pack. https://pmc.ncbi.nlm.nih.gov/articles/PMC9865236/
- **[W31] Merrigan et al., CMJ force-time reliability and comparability across force-plate systems.** Supports device/configuration-specific agreement qualification. https://pubmed.ncbi.nlm.nih.gov/37815253/
- **[W32] Hori et al., reliability and sampling frequency.** Sampling frequency affects some derived outcomes and must be a contract dimension. https://ro.ecu.edu.au/cgi/viewcontent.cgi?article=1506&context=ecuworks
- **[W33] Meylan et al., CMJ movement-onset thresholds.** Event definitions materially affect results and must be frozen and tested. https://pubmed.ncbi.nlm.nih.gov/20664368/
- **[W34] Reliability of vertical-jump force-time metrics in collegiate athletes.** Recent evidence that reliability is metric-specific, not guaranteed by hardware capability. https://pmc.ncbi.nlm.nih.gov/articles/PMC12733763/
