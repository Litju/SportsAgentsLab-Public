
# SportsAgentsLab Measurement Evidence Factory - Architecture Bundle

Research freeze: 2026-08-03

This bundle contains the curated baseline architecture documents for owner review:

- `SAL-MEF-SDD-0.1.md` / `.docx` / `.pdf` - System Design Description.
- `SAL-MEF-TDD-0.1.md` / `.docx` / `.pdf` - Technical Design Document.
- `SAL-MEF-ADR-0.1.md` / `.docx` / `.pdf` - Architecture Decision Record compendium.
- `diagrams/` - source DOT files and rendered architecture figures.
- `bundle-manifest.json` - file hashes generated after publication.

The documents do not authorize implementation. They define a review baseline and preserve unresolved qualification decisions.
