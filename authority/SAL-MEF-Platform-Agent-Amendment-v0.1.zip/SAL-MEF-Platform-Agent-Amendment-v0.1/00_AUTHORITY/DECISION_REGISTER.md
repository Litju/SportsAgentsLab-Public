# Platform + Agent Amendment Decision Register

| ID | Decision | Disposition |
|---|---|---|
| ADR-031 | Desktop-first web product; no native desktop v1 | Accepted candidate |
| ADR-032 | Vercel-first prototype/development deployment; Hobby non-commercial boundary | Accepted candidate |
| ADR-033 | Eve becomes canonical MEF agent runtime behind adapter | Accepted candidate |
| ADR-034 | OpenCode Go is primary model access; Vercel AI Gateway disabled by default | Accepted candidate |
| ADR-035 | AI SDK is implementation plumbing, not product architecture | Accepted candidate |
| ADR-036 | ML-97 Command/Job system is v1 workflow baseline; Temporal deferred | Accepted candidate; effective after ML-97 acceptance |
| ADR-037 | Vercel Blob private is primary Vercel artifact adapter; S3 adapter retained | Accepted candidate |
| ADR-038 | PostgreSQL remains provider-neutral; Neon is initial Vercel managed candidate | Accepted candidate |
| ADR-039 | One primary Next.js Vercel app; same-origin server/API/Eve integration | Accepted candidate |
| ADR-040 | Preview-first velocity; stable governed core + fast-moving agent/product layer | Accepted candidate |
| ADR-041 | Vercel Sandbox only for special isolated workloads | Accepted candidate |
| ADR-042 | Vercel-first but core provider coupling forbidden; adapters isolate vendor APIs | Accepted candidate |
| ADR-043 | Python scientific kernel stays independent; Vercel Python Functions eligible adapter | Accepted candidate |
| ADR-044 | Eve approvals do not replace MEF authority records | Accepted candidate |

## Decision hierarchy

These decisions may amend platform/runtime clauses but may not weaken scientific, evidence, safety, privacy, or practitioner-authority requirements. Any conflict is resolved in favor of the stricter governed-scientific boundary unless the founder records a separate explicit scientific authority change.
